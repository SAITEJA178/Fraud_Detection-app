import { ShieldAlert, CheckCircle, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

export interface Transaction {
  id: string;
  merchant: string;
  amount: string;
  risk: number;
  status: "blocked" | "approved" | "pending";
  time: string;
}

const transactions: Transaction[] = [
  { id: "TX-9928", merchant: "CyberDyne Systems", amount: "₹1,02,450.00", risk: 98, status: "blocked", time: "2s ago" },
  { id: "TX-9927", merchant: "Neo-Tokyo Market", amount: "₹4,520.00", risk: 12, status: "approved", time: "5s ago" },
  { id: "TX-9926", merchant: "Orbital Transport", amount: "₹89,000.00", risk: 45, status: "pending", time: "12s ago" },
  { id: "TX-9925", merchant: "Padugupadu Vendor", amount: "₹21,000.00", risk: 85, status: "blocked", time: "18s ago" },
  { id: "TX-9924", merchant: "Starlink Comm", amount: "₹12,000.00", risk: 5, status: "approved", time: "24s ago" },
];

interface TransactionListProps {
  onSelect: (tx: Transaction) => void;
}

export function TransactionList({ onSelect }: TransactionListProps) {
  return (
    <div className="glass-panel rounded-xl overflow-hidden h-full flex flex-col">
      <div className="p-4 border-b border-white/[0.08] flex items-center justify-between">
        <h3 className="font-display font-bold text-lg text-white tracking-wide">
          LIVE FEED
        </h3>
        <div className="flex gap-2">
           <span className="flex h-2 w-2 rounded-full bg-electric-red animate-pulse"></span>
           <span className="text-xs font-mono text-muted-foreground">MONITORING</span>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto">
        <div className="flex flex-col">
          {transactions.map((tx) => (
            <div 
              key={tx.id}
              onClick={() => onSelect(tx)}
              className="group flex items-center justify-between p-4 border-b border-white/[0.05] hover:bg-white/[0.05] transition-colors cursor-pointer relative overflow-hidden"
            >
              {/* Hover highlight line */}
              <div className="absolute left-0 top-0 bottom-0 w-1 bg-neon-cyan opacity-0 group-hover:opacity-100 transition-opacity" />
              
              <div className="flex items-center gap-4">
                <div className={cn(
                  "h-10 w-10 rounded-lg flex items-center justify-center border",
                  tx.status === "blocked" ? "bg-electric-red/10 border-electric-red/30 text-electric-red" :
                  tx.status === "pending" ? "bg-amber/10 border-amber/30 text-amber" :
                  "bg-neon-cyan/10 border-neon-cyan/30 text-neon-cyan"
                )}>
                  {tx.status === "blocked" ? <ShieldAlert size={18} /> :
                   tx.status === "pending" ? <Clock size={18} /> :
                   <CheckCircle size={18} />}
                </div>
                <div>
                  <div className="text-white font-medium text-sm">{tx.merchant}</div>
                  <div className="text-xs text-muted-foreground font-mono">{tx.id} • {tx.time}</div>
                </div>
              </div>

              <div className="text-right">
                <div className="text-white font-display font-bold tracking-wide">{tx.amount}</div>
                <div className={cn(
                  "text-xs font-bold",
                  tx.risk > 80 ? "text-electric-red" : 
                  tx.risk > 40 ? "text-amber" : "text-neon-cyan"
                )}>
                  Risk: {tx.risk}%
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
