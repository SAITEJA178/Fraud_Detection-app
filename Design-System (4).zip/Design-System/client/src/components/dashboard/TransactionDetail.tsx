import { motion } from "framer-motion";
import { Transaction } from "./TransactionList";
import { X, ShieldAlert, CheckCircle, Fingerprint, MapPin, Smartphone, CreditCard, Globe, Clock, User } from "lucide-react";
import { cn } from "@/lib/utils";

interface TransactionDetailProps {
  transaction: Transaction;
  onClose: () => void;
}

export function TransactionDetail({ transaction, onClose }: TransactionDetailProps) {
  const isHighRisk = transaction.risk > 80 || transaction.status === "blocked";
  const colorClass = isHighRisk ? "text-electric-red" : "text-neon-cyan";
  const borderClass = isHighRisk ? "border-electric-red/50" : "border-neon-cyan/50";
  const bgClass = isHighRisk ? "bg-electric-red/10" : "bg-neon-cyan/10";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Blurred Backdrop */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-background/80 backdrop-blur-xl"
      />

      {/* Floating Glass Card */}
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className={cn(
          "relative w-full max-w-2xl glass-panel rounded-2xl overflow-hidden border p-0 shadow-2xl",
          borderClass
        )}
      >
        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Left Side: Visual Representation */}
          <div className={cn("p-8 flex flex-col items-center justify-center relative overflow-hidden", bgClass)}>
            <div className="absolute inset-0 opacity-20 bg-[url('/assets/images/grid-bg.png')] bg-cover mix-blend-overlay" />
            
            {/* 3D Card Mockup (CSS only) */}
            <div className="w-64 h-40 rounded-xl bg-gradient-to-br from-white/10 to-white/5 border border-white/20 backdrop-blur-md relative transform rotate-y-12 rotate-x-12 shadow-2xl transition-transform hover:rotate-0 duration-500 group perspective-1000">
              <div className="absolute top-4 right-4">
                <CreditCard className="text-white/50 h-6 w-6" />
              </div>
              <div className="absolute bottom-4 left-4 text-white font-mono text-sm tracking-widest opacity-80">
                •••• •••• •••• {transaction.id.slice(-4)}
              </div>
              <div className="absolute top-4 left-4 h-8 w-10 bg-gradient-to-r from-yellow-200 to-yellow-500 rounded opacity-80" />
            </div>

            <div className="mt-8 text-center z-10">
              <div className="text-6xl font-display font-bold text-white tracking-tighter mb-2">
                {transaction.risk}
                <span className="text-2xl text-white/50">%</span>
              </div>
              <div className={cn("text-sm font-bold tracking-widest uppercase", colorClass)}>
                RISK SCORE
              </div>
            </div>
          </div>

          {/* Right Side: Data Details */}
          <div className="p-8 bg-black/40">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h3 className="text-2xl font-display font-bold text-white mb-1 uppercase">{transaction.merchant}</h3>
                <div className="text-muted-foreground font-mono text-xs tracking-tighter">NODE_ID: {transaction.id}</div>
              </div>
              <div className="text-right">
                <div className="text-xl font-bold text-white">₹{parseInt(transaction.amount.replace(/[^0-9.-]+/g,"")).toLocaleString('en-IN')}</div>
                <div className="text-xs text-muted-foreground uppercase">{transaction.time}</div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-3 p-3 rounded bg-white/5 border border-white/10">
                <Fingerprint className="text-neon-cyan h-5 w-5" />
                <div className="flex-1">
                  <div className="text-xs text-muted-foreground uppercase tracking-wider">Neural Fingerprint</div>
                  <div className="text-sm text-white font-mono">Behavioral Match 99%</div>
                </div>
                <div className="text-xs text-neon-cyan font-bold">SYMLINK</div>
              </div>

              <div className="flex items-center gap-3 p-3 rounded bg-white/5 border border-white/10">
                <MapPin className={cn("h-5 w-5", isHighRisk ? "text-electric-red" : "text-amber")} />
                <div className="flex-1">
                  <div className="text-xs text-muted-foreground uppercase tracking-wider">Geo-Telemetry</div>
                  <div className="text-sm text-white font-mono truncate">Sector Sync Active</div>
                </div>
                <div className={cn("text-xs font-bold", isHighRisk ? "text-electric-red" : "text-amber")}>
                  {isHighRisk ? "THREAT" : "SYNC"}
                </div>
              </div>

              <div className="p-3 rounded bg-white/5 border border-white/10">
                <div className="text-[10px] font-mono text-muted-foreground uppercase mb-2">Sentinel Response AI</div>
                <p className="text-xs text-white/70 leading-relaxed italic">
                  {isHighRisk 
                    ? "Detected multi-vector velocity spike. Recommended Action: Immediate sector isolation and refund initiation."
                    : "Pattern verified against consumer baseline. No anomalies detected."}
                </p>
              </div>
            </div>

            <div className="mt-8 flex gap-3">
              <button 
                onClick={onClose}
                className="flex-1 py-3 rounded bg-white/10 hover:bg-white/20 text-white border border-white/10 font-bold tracking-wide transition-colors text-xs"
              >
                DISMISS
              </button>
              {isHighRisk ? (
                <button 
                  onClick={onClose}
                  className="flex-1 py-3 rounded bg-electric-red hover:bg-white hover:text-black text-white font-bold tracking-wide transition-all text-xs shadow-[0_0_20px_rgba(255,43,43,0.3)]"
                >
                  INITIATE REFUND
                </button>
              ) : (
                <button 
                  onClick={onClose}
                  className="flex-1 py-3 rounded bg-neon-cyan hover:bg-white hover:text-black text-black font-bold tracking-wide transition-all text-xs"
                >
                  VERIFY NODE
                </button>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
