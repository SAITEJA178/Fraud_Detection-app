import { cn } from "@/lib/utils";

interface StatCardProps {
  label: string;
  value: string;
  trend?: string;
  trendUp?: boolean;
  status?: "normal" | "warning" | "critical";
  className?: string;
  icon?: React.ReactNode;
}

export function StatCard({ label, value, trend, trendUp, status = "normal", className, icon }: StatCardProps) {
  const statusColors = {
    normal: "border-white/[0.08]",
    warning: "border-amber text-amber",
    critical: "border-electric-red text-electric-red animate-pulse-slow"
  };

  return (
    <div className={cn("glass-panel p-6 rounded-xl flex flex-col gap-2 relative overflow-hidden group", className)}>
      <div className="absolute top-0 right-0 p-4 opacity-50 group-hover:opacity-100 transition-opacity">
        {icon}
      </div>
      
      <span className="text-sm font-mono text-muted-foreground uppercase tracking-wider z-10">
        {label}
      </span>
      
      <div className="flex items-end gap-3 z-10">
        <span className={cn(
          "text-4xl font-display font-bold tracking-tight",
          status === "critical" ? "text-electric-red text-glow-red" : 
          status === "warning" ? "text-amber" : "text-white"
        )}>
          {value}
        </span>
        {trend && (
          <span className={cn(
            "text-sm font-mono mb-1",
            trendUp ? "text-neon-cyan" : "text-electric-red"
          )}>
            {trendUp ? "↑" : "↓"} {trend}
          </span>
        )}
      </div>

      {/* Decorative background glow */}
      {status === "critical" && (
        <div className="absolute -right-10 -bottom-10 w-32 h-32 bg-electric-red/20 blur-[50px] rounded-full" />
      )}
      {status === "normal" && (
        <div className="absolute -right-10 -bottom-10 w-32 h-32 bg-neon-cyan/10 blur-[50px] rounded-full" />
      )}
    </div>
  );
}
