import { useRef, useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function FraudGraph() {
  const [nodes, setNodes] = useState<any[]>([]);
  const [lines, setLines] = useState<any[]>([]);

  useEffect(() => {
    // Generate static nodes
    const newNodes = new Array(30).fill(0).map((_, i) => {
      const isRisk = Math.random() > 0.85;
      return {
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100,
        isRisk,
        color: isRisk ? "#FF2B2B" : (Math.random() > 0.5 ? "#00F6FF" : "#ffffff")
      };
    });
    setNodes(newNodes);

    // Generate connections
    const newLines: any[] = [];
    newNodes.forEach((node, i) => {
      newNodes.slice(i + 1).forEach((target) => {
        const dist = Math.sqrt(Math.pow(node.x - target.x, 2) + Math.pow(node.y - target.y, 2));
        if (dist < 25 && Math.random() > 0.6) {
          newLines.push({
            id: `${node.id}-${target.id}`,
            x1: node.x,
            y1: node.y,
            x2: target.x,
            y2: target.y,
            isRisk: node.isRisk || target.isRisk
          });
        }
      });
    });
    setLines(newLines);
  }, []);

  return (
    <div className="w-full h-full min-h-[400px] relative bg-slate-950/50 backdrop-blur-sm overflow-hidden border border-white/5 rounded-xl">
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_#334155_1px,_transparent_1px)] bg-[size:24px_24px]" />
      
      <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
        {/* Connections */}
        {lines.map((line) => (
          <motion.line
            key={line.id}
            x1={line.x1}
            y1={line.y1}
            x2={line.x2}
            y2={line.y2}
            stroke={line.isRisk ? "#FF2B2B" : "#00F6FF"}
            strokeWidth={line.isRisk ? "0.3" : "0.1"}
            strokeOpacity={line.isRisk ? "0.6" : "0.2"}
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 1 }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
          />
        ))}

        {/* Nodes */}
        {nodes.map((node) => (
          <g key={node.id}>
            <motion.circle
              cx={node.x}
              cy={node.y}
              r={node.isRisk ? "1" : "0.6"}
              fill={node.color}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: Math.random() * 0.5 }}
            />
            {node.isRisk && (
              <motion.circle
                cx={node.x}
                cy={node.y}
                r="1.5"
                stroke="#FF2B2B"
                strokeWidth="0.1"
                fill="none"
                animate={{ scale: [1, 2], opacity: [0.5, 0] }}
                transition={{ repeat: Infinity, duration: 2 }}
              />
            )}
          </g>
        ))}
      </svg>
      
      <div className="absolute top-4 left-4 z-20 pointer-events-none">
        <div className="glass-panel px-3 py-1 rounded border-l-2 border-neon-cyan">
          <span className="text-xs font-mono text-neon-cyan animate-pulse">LIVE TOPOLOGY</span>
        </div>
      </div>

      <div className="absolute bottom-4 right-4 z-20 pointer-events-none text-[8px] font-mono text-white/30 uppercase tracking-widest">
        Neural Node Visualization v2.4
      </div>
    </div>
  );
}
