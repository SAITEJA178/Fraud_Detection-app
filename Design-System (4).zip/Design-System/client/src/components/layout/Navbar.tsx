import { Link } from "wouter";
import { ShieldCheck, Activity, Map, Bell, Lock, MessageCircle, FileUp } from "lucide-react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";

export function Navbar() {
  const [location] = useLocation();

  const isActive = (path: string) => location === path;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-white/[0.08] bg-background/50 backdrop-blur-xl h-16 flex items-center px-6">
      <div className="flex items-center gap-3">
        <div className="relative flex h-8 w-8 items-center justify-center rounded bg-neon-cyan/20">
          <ShieldCheck className="h-5 w-5 text-neon-cyan" />
          <div className="absolute inset-0 animate-pulse rounded bg-neon-cyan/20 blur-sm"></div>
        </div>
        <span className="font-display text-xl font-bold tracking-wider text-white uppercase">
          FRAUD DETECTION <span className="text-neon-cyan">AI</span>
        </span>
      </div>

      <div className="mx-8 flex items-center gap-1 bg-white/[0.03] p-1 rounded-full border border-white/[0.05]">
        <Link href="/">
          <a className={cn(
            "flex items-center gap-2 rounded-full px-4 py-1.5 text-sm font-medium transition-colors",
            isActive("/") ? "bg-white/[0.1] text-white shadow-sm" : "text-muted-foreground hover:text-white"
          )}>
            <Activity className="h-4 w-4 text-neon-cyan" />
            Dashboard
          </a>
        </Link>
        <Link href="/map">
          <a className={cn(
            "flex items-center gap-2 rounded-full px-4 py-1.5 text-sm font-medium transition-colors",
            isActive("/map") ? "bg-white/[0.1] text-white shadow-sm" : "text-muted-foreground hover:text-white"
          )}>
            <Map className="h-4 w-4" />
            Live Map
          </a>
        </Link>
        <Link href="/security">
          <a className={cn(
            "flex items-center gap-2 rounded-full px-4 py-1.5 text-sm font-medium transition-colors",
            isActive("/security") ? "bg-white/[0.1] text-white shadow-sm" : "text-muted-foreground hover:text-white"
          )}>
            <Lock className="h-4 w-4" />
            Guardian
          </a>
        </Link>
        <Link href="/batch">
          <a className={cn(
            "flex items-center gap-2 rounded-full px-4 py-1.5 text-sm font-medium transition-colors",
            isActive("/batch") ? "bg-white/[0.1] text-white shadow-sm" : "text-muted-foreground hover:text-white"
          )}>
            <FileUp className="h-4 w-4" />
            Batch
          </a>
        </Link>
        <Link href="/chat">
          <a className={cn(
            "flex items-center gap-2 rounded-full px-4 py-1.5 text-sm font-medium transition-colors",
            isActive("/chat") ? "bg-white/[0.1] text-white shadow-sm" : "text-muted-foreground hover:text-white"
          )}>
            <MessageCircle className="h-4 w-4" />
            Assistant
          </a>
        </Link>
      </div>

      <div className="ml-auto flex items-center gap-4">
        <div className="flex items-center gap-2 text-xs text-muted-foreground font-mono">
          <span className="inline-block h-2 w-2 rounded-full bg-neon-cyan animate-pulse"></span>
          SYSTEM ONLINE
        </div>
        <button className="relative rounded-full p-2 text-muted-foreground hover:text-white hover:bg-white/[0.05] transition-colors">
          <Bell className="h-5 w-5" />
          <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-electric-red border border-background"></span>
        </button>
        <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-neon-cyan to-blue-600 border border-white/20"></div>
      </div>
    </nav>
  );
}
