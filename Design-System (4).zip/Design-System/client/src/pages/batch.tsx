import { Navbar } from "@/components/layout/Navbar";
import { FileUp, Database, AlertCircle, CheckCircle, UploadCloud, X, ShieldAlert, ShieldCheck, FileText } from "lucide-react";
import { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import gridBg from "@/assets/images/grid-bg.png";

interface ProcessedResult {
  filename: string;
  total: number;
  frauds: number;
  negatives: number;
  safe: number;
  timestamp: string;
  status: 'processing' | 'completed';
}

export default function BatchPage() {
  const [isUploading, setIsUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState<ProcessedResult[]>([]);
  const [selectedResult, setSelectedResult] = useState<ProcessedResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      startProcessing(file.name);
    }
  };

  const startProcessing = (filename: string) => {
    setIsUploading(true);
    setProgress(0);
    
    let p = 0;
    const interval = setInterval(() => {
      p += Math.random() * 15;
      if (p >= 100) {
        p = 100;
        clearInterval(interval);
        setTimeout(() => {
          setIsUploading(false);
          const newResult: ProcessedResult = {
            filename,
            total: Math.floor(Math.random() * 5000) + 1000,
            frauds: Math.floor(Math.random() * 50) + 10,
            negatives: Math.floor(Math.random() * 100) + 20,
            safe: 0,
            timestamp: new Date().toLocaleTimeString(),
            status: 'completed'
          };
          newResult.safe = newResult.total - newResult.frauds - newResult.negatives;
          setResults(prev => [newResult, ...prev]);
        }, 500);
      }
      setProgress(p);
    }, 150);
  };

  const downloadFile = (type: 'frauds' | 'negatives' | 'safe', result: ProcessedResult) => {
    const count = result[type];
    const content = `Type: ${type.toUpperCase()}\nSource: ${result.filename}\nRecords: ${count}\nProcessed at: ${result.timestamp}\nStatus: VERIFIED BY SENTINEL AI`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${type}_records_${result.filename.split('.')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden relative">
      <div 
        className="fixed inset-0 z-0 opacity-40 pointer-events-none mix-blend-screen"
        style={{
          backgroundImage: `url(${gridBg})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />
      <Navbar />

      <main className="relative z-10 pt-24 px-6 max-w-6xl mx-auto pb-12">
        <div className="mb-8">
          <h1 className="text-4xl font-display font-bold text-white mb-2 tracking-wider">BATCH PROCESSING</h1>
          <p className="text-muted-foreground font-mono text-sm uppercase tracking-widest">Neural Mass Data Analysis Node</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Upload Section */}
          <div className="lg:col-span-1 space-y-6">
            <input 
              type="file" 
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".csv"
              className="hidden" 
            />
            
            <div 
              className="glass-panel p-8 rounded-2xl border-dashed border-white/20 flex flex-col items-center justify-center text-center group hover:border-neon-cyan/50 transition-colors cursor-pointer" 
              onClick={() => fileInputRef.current?.click()}
            >
              <div className="h-20 w-20 rounded-full bg-neon-cyan/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <UploadCloud className="h-10 w-10 text-neon-cyan" />
              </div>
              <h3 className="text-xl font-display font-bold text-white mb-2">UPLOAD CSV DATASET</h3>
              <p className="text-sm text-muted-foreground mb-6">Process batch transactions for neural fraud detection and file separation.</p>
              <div className="text-xs font-mono text-neon-cyan bg-neon-cyan/10 px-4 py-2 rounded border border-neon-cyan/20">
                .CSV REQUIRED • ANALYZING THREATS
              </div>
            </div>

            {isUploading && (
              <div className="glass-panel p-6 rounded-xl space-y-4 border-neon-cyan/30">
                <div className="flex justify-between text-xs font-mono text-white/70">
                  <span className="truncate mr-4">NEURAL_SCANNING...</span>
                  <span>{Math.floor(progress)}%</span>
                </div>
                <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    className="h-full bg-neon-cyan shadow-[0_0_10px_#00F6FF]"
                  />
                </div>
                <div className="flex items-center gap-2 text-[10px] font-mono text-amber animate-pulse">
                  <AlertCircle size={12} />
                  IDENTIFYING THREAT VECTORS...
                </div>
              </div>
            )}
          </div>

          {/* Results List */}
          <div className="lg:col-span-2 space-y-6">
            <div className="glass-panel rounded-2xl overflow-hidden flex flex-col h-[600px]">
              <div className="p-4 border-b border-white/[0.08] bg-white/[0.02] flex items-center justify-between">
                <h3 className="text-lg font-display font-bold text-white flex items-center gap-2">
                  <Database className="h-5 w-5 text-neon-cyan" />
                  ANALYSIS HISTORY
                </h3>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                <AnimatePresence>
                  {results.map((res, idx) => (
                    <motion.div
                      key={res.filename + res.timestamp}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="group p-4 rounded-xl bg-white/5 border border-white/10 hover:border-neon-cyan/40 hover:bg-white/10 transition-all cursor-pointer"
                      onClick={() => setSelectedResult(res)}
                    >
                      <div className="flex justify-between items-center mb-3">
                        <div className="flex items-center gap-3">
                          <CheckCircle className="h-5 w-5 text-neon-cyan" />
                          <span className="text-sm text-white font-medium">{res.filename}</span>
                        </div>
                        <span className="text-[10px] font-mono text-muted-foreground">{res.timestamp}</span>
                      </div>
                      <div className="grid grid-cols-3 gap-2">
                        <div className="bg-electric-red/10 p-2 rounded border border-electric-red/20 text-center">
                          <div className="text-[10px] text-electric-red uppercase font-mono">Threats</div>
                          <div className="text-lg font-bold text-white tracking-tighter">{res.frauds}</div>
                        </div>
                        <div className="bg-amber/10 p-2 rounded border border-amber/20 text-center">
                          <div className="text-[10px] text-amber uppercase font-mono">Negatives</div>
                          <div className="text-lg font-bold text-white tracking-tighter">{res.negatives}</div>
                        </div>
                        <div className="bg-neon-cyan/10 p-2 rounded border border-neon-cyan/20 text-center">
                          <div className="text-[10px] text-neon-cyan uppercase font-mono">Safe</div>
                          <div className="text-lg font-bold text-white tracking-tighter">{res.safe}</div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
                {results.length === 0 && !isUploading && (
                  <div className="h-full flex flex-col items-center justify-center text-muted-foreground opacity-30">
                    <Database size={48} className="mb-4" />
                    <p className="font-mono text-sm">NO CSV DATASET ANALYZED</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Result Detail Modal */}
      <AnimatePresence>
        {selectedResult && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }}
              onClick={() => setSelectedResult(null)}
              className="absolute inset-0 bg-background/80 backdrop-blur-xl"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-2xl glass-panel rounded-2xl overflow-hidden border border-neon-cyan/30 shadow-2xl p-0"
            >
              <div className="bg-neon-cyan/10 p-6 border-b border-neon-cyan/20 flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <Database className="text-neon-cyan h-6 w-6" />
                  <h3 className="text-2xl font-display font-bold text-white">{selectedResult.filename}</h3>
                </div>
                <button onClick={() => setSelectedResult(null)} className="text-white hover:text-neon-cyan transition-colors">
                  <X size={24} />
                </button>
              </div>

              <div className="p-8 space-y-8">
                <div className="grid grid-cols-3 gap-6">
                   <div className="text-center group" onClick={(e) => { e.stopPropagation(); downloadFile('frauds', selectedResult); }}>
                     <div className="text-4xl font-display font-bold text-electric-red mb-1">{selectedResult.frauds}</div>
                     <div className="text-xs text-muted-foreground uppercase font-mono tracking-widest flex items-center justify-center gap-1">
                       <ShieldAlert size={10} /> THREATS
                     </div>
                     <button className="mt-2 text-[10px] text-electric-red border border-electric-red/30 px-2 py-1 rounded hover:bg-electric-red/10 transition-colors flex items-center gap-1 mx-auto">
                       <FileText size={10} /> DOWNLOAD
                     </button>
                   </div>
                   <div className="text-center group" onClick={(e) => { e.stopPropagation(); downloadFile('negatives', selectedResult); }}>
                     <div className="text-4xl font-display font-bold text-amber mb-1">{selectedResult.negatives}</div>
                     <div className="text-xs text-muted-foreground uppercase font-mono tracking-widest flex items-center justify-center gap-1">
                       <AlertCircle size={10} /> NEGATIVES
                     </div>
                     <button className="mt-2 text-[10px] text-amber border border-amber/30 px-2 py-1 rounded hover:bg-amber/10 transition-colors flex items-center gap-1 mx-auto">
                       <FileText size={10} /> DOWNLOAD
                     </button>
                   </div>
                   <div className="text-center group" onClick={(e) => { e.stopPropagation(); downloadFile('safe', selectedResult); }}>
                     <div className="text-4xl font-display font-bold text-neon-cyan mb-1">{selectedResult.safe}</div>
                     <div className="text-xs text-muted-foreground uppercase font-mono tracking-widest flex items-center justify-center gap-1">
                       <ShieldCheck size={10} /> SAFE
                     </div>
                     <button className="mt-2 text-[10px] text-neon-cyan border border-neon-cyan/30 px-2 py-1 rounded hover:bg-neon-cyan/10 transition-colors flex items-center gap-1 mx-auto">
                       <FileText size={10} /> DOWNLOAD
                     </button>
                   </div>
                </div>

                <div className="space-y-4">
                  <h4 className="text-sm font-mono text-muted-foreground uppercase tracking-widest">Neural Breakdown</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs text-white/70">
                      <span>Neural Confidence Level</span>
                      <span>99.8%</span>
                    </div>
                    <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
                      <div className="h-full w-[99.8%] bg-neon-cyan shadow-[0_0_10px_#00F6FF]" />
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded bg-white/5 border border-white/10">
                  <div className="text-xs font-mono text-neon-cyan mb-2 uppercase tracking-widest">Sentinel Insight</div>
                  <p className="text-sm text-white/70 italic">
                    "Analysis complete. Found {selectedResult.frauds} critical threat vectors. File separation complete. You can now download the isolated datasets for each category."
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
