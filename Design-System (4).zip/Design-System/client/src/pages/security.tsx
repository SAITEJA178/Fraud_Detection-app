import { Navbar } from "@/components/layout/Navbar";
import aiSentinelImg from "@/assets/images/ai-sentinel.png";
import gridBg from "@/assets/images/grid-bg.png";
import { ShieldCheck, Lock, Eye, Server } from "lucide-react";
import { motion } from "framer-motion";

export default function SecurityPage() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden relative">
      <div 
        className="fixed inset-0 z-0 opacity-40 pointer-events-none mix-blend-screen"
        style={{
          backgroundImage: `url(${gridBg})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />
      
      <Navbar />

      <main className="relative z-10 pt-24 px-6 pb-10 max-w-7xl mx-auto h-full flex flex-col items-center justify-center min-h-[calc(100vh-6rem)]">
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center w-full">
          {/* Left: AI Visual */}
          <div className="relative flex justify-center">
            <div className="absolute inset-0 bg-neon-cyan/20 blur-[100px] rounded-full" />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 1 }}
              className="relative z-10 w-[500px] h-[500px] rounded-full border border-neon-cyan/30 bg-black/50 backdrop-blur-sm overflow-hidden flex items-center justify-center shadow-[0_0_50px_rgba(0,246,255,0.2)]"
            >
              <img 
                src={aiSentinelImg} 
                alt="AI Sentinel" 
                className="w-full h-full object-cover opacity-80 mix-blend-screen"
              />
              
              {/* Scanning effect */}
              <div className="absolute top-0 left-0 right-0 h-1 bg-neon-cyan/50 shadow-[0_0_20px_#00F6FF] animate-[scan_3s_ease-in-out_infinite]" />
              
              {/* HUD Overlay */}
              <div className="absolute inset-0 border-[20px] border-transparent border-t-neon-cyan/20 border-b-neon-cyan/20 rounded-full animate-spin-slow" />
              <div className="absolute inset-4 border border-dashed border-white/20 rounded-full animate-reverse-spin" />
            </motion.div>
          </div>

          {/* Right: Text Content */}
          <div className="space-y-8">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neon-cyan/10 border border-neon-cyan/30 text-neon-cyan text-xs font-mono mb-4">
                <ShieldCheck className="h-3 w-3" />
                TRUST & SECURITY ENGINE v2.4
              </div>
              <h1 className="text-5xl font-display font-bold text-white mb-4 leading-tight">
                AI Sentinel <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-cyan to-blue-500">Guardian Protocol</span>
              </h1>
              <p className="text-lg text-muted-foreground/80 max-w-lg leading-relaxed">
                Our autonomous AI guardian analyzes millions of data points in real-time. 
                It never sleeps, learning from every interaction to build an impenetrable 
                defense against evolving fraud patterns.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="glass-panel p-4 rounded-lg border-l-2 border-neon-cyan">
                <Eye className="h-5 w-5 text-neon-cyan mb-2" />
                <div className="text-2xl font-bold text-white mb-1">99.9%</div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider">Detection Rate</div>
              </div>
              <div className="glass-panel p-4 rounded-lg border-l-2 border-neon-cyan">
                <Server className="h-5 w-5 text-neon-cyan mb-2" />
                <div className="text-2xl font-bold text-white mb-1">5ms</div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider">Processing Time</div>
              </div>
            </div>

            <div className="glass-panel p-6 rounded-lg bg-electric-red/5 border-electric-red/20">
              <h3 className="text-electric-red font-bold flex items-center gap-2 mb-2">
                <Lock className="h-4 w-4" />
                Recent Intervention
              </h3>
              <p className="text-sm text-white/80">
                Sentinel blocked a coordinated botnet attack targeting 150+ merchant accounts at 04:23 AM UTC. 
                No manual intervention required.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
