import { Navbar } from "@/components/layout/Navbar";
import { useEffect, useState, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { Search, Bot, Activity, ShieldAlert, Globe } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const LOCATIONS = [
  { city: "Nellore", state: "Andhra Pradesh", country: "India", lat: 14.4426, lon: 79.9865 },
  { city: "Hyderabad", state: "Telangana", country: "India", lat: 17.3850, lon: 78.4867 },
  { city: "Padugupadu", state: "Andhra Pradesh", country: "India", lat: 14.4925, lon: 79.9922 },
  { city: "Mumbai", state: "Maharashtra", country: "India", lat: 19.0760, lon: 72.8777 },
  { city: "Delhi", state: "Delhi", country: "India", lat: 28.6139, lon: 77.2090 },
  { city: "Bangalore", state: "Karnataka", country: "India", lat: 12.9716, lon: 77.5946 },
  { city: "Chennai", state: "Tamil Nadu", country: "India", lat: 13.0827, lon: 80.2707 },
  { city: "Kolkata", state: "West Bengal", country: "India", lat: 22.5726, lon: 88.3639 },
];

interface Transaction {
  id: string;
  amount: number;
  status: "fraud" | "normal";
  ip: string;
  city: string;
  state: string;
  lat: number;
  lon: number;
  timestamp: number;
  cardNumber: string;
}

export default function MapPage() {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.LayerGroup | null>(null);
  
  const [stats, setStats] = useState({ total: 1247, fraud: 382 });
  const [recentFrauds, setRecentFrauds] = useState<Transaction[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);

  useEffect(() => {
    if (!mapContainerRef.current || mapRef.current) return;

    mapRef.current = L.map(mapContainerRef.current, {
      center: [22.5937, 78.9629], // Adjusted center for better India view
      zoom: 5,
      zoomControl: false,
      attributionControl: false
    });

    // Using a more colourful/vibrant map style to match the user's reference
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
    }).addTo(mapRef.current);

    markersRef.current = L.layerGroup().addTo(mapRef.current);

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      if (!mapRef.current || !markersRef.current) return;

      const loc = LOCATIONS[Math.floor(Math.random() * LOCATIONS.length)];
      const isFraud = Math.random() < 0.25;
      const tx: Transaction = {
        id: "TX-" + Math.random().toString(36).substr(2, 6).toUpperCase(),
        amount: Math.floor(Math.random() * 50000) + 500,
        status: isFraud ? "fraud" : "normal",
        ip: `103.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
        cardNumber: `**** **** **** ${Math.floor(Math.random() * 8999) + 1000}`,
        ...loc,
        timestamp: Date.now()
      };

      setStats(prev => ({
        total: prev.total + 1,
        fraud: prev.fraud + (isFraud ? 1 : 0)
      }));

      if (isFraud) {
        setRecentFrauds(prev => [tx, ...prev].slice(0, 5));
        
        const color = '#FF2B2B';
        const shadow = '0 0 15px #FF2B2B';
        
        const markerHtml = `
          <div class="relative flex items-center justify-center">
            <div style="width: 14px; height: 14px; background-color: ${color}; border-radius: 50%; box-shadow: ${shadow}; border: 2px solid white;"></div>
            <div class="absolute w-8 h-8 border-2 border-[#FF2B2B] rounded-full animate-ping opacity-50"></div>
          </div>
        `;

        const icon = L.divIcon({
          html: markerHtml,
          className: 'custom-marker',
          iconSize: [24, 24],
          iconAnchor: [12, 12]
        });

        const marker = L.marker([tx.lat, tx.lon], { icon }).addTo(markersRef.current);
        
        setTimeout(() => {
          if (markersRef.current) markersRef.current.removeLayer(marker);
        }, 4000);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim() || !mapRef.current) return;

    const matched = LOCATIONS.find(l => 
      l.city.toLowerCase().includes(searchQuery.toLowerCase())
    );

    if (matched) {
      mapRef.current.flyTo([matched.lat, matched.lon], 10);
      setAiAnalysis(`IMMEDIATE ALERT: Analyzing Sector ${matched.city}. Multiple high-risk card-not-present transactions detected. Recommend enabling P-03 Sector Isolation for IP range 103.x.x.x.`);
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFDFD] text-foreground overflow-hidden flex flex-col font-sans">
      <style>{`
        .leaflet-container { background: #AAD3DF !important; }
        .leaflet-tile-pane { filter: saturate(1.2); }
      `}</style>
      
      <Navbar />

      <div className="flex-1 flex flex-col lg:flex-row pt-16 h-[calc(100vh-4rem)] overflow-hidden">
        {/* Real-time Dashboard Sidebar */}
        <div className="w-full lg:w-96 bg-[#1A1A1A] border-r border-black/10 p-6 flex flex-col gap-6 z-20 shadow-2xl shrink-0 overflow-y-auto custom-scrollbar">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-neon-cyan text-[10px] font-mono tracking-widest uppercase">
              <Activity size={12} className="animate-pulse" />
              Live Neural Stream
            </div>
            <h1 className="text-white text-2xl font-bold tracking-tight">Fraud Command</h1>
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white/5 border border-white/10 p-4 rounded-xl">
              <div className="text-[10px] text-muted-foreground uppercase font-mono mb-1">Total Scans</div>
              <div className="text-2xl font-bold text-white tabular-nums">{stats.total}</div>
            </div>
            <div className="bg-electric-red/10 border border-electric-red/20 p-4 rounded-xl">
              <div className="text-[10px] text-electric-red uppercase font-mono mb-1">Threats</div>
              <div className="text-2xl font-bold text-electric-red tabular-nums">{stats.fraud}</div>
            </div>
          </div>

          <div className="flex-1 min-h-0 flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-white text-xs font-bold uppercase tracking-widest flex items-center gap-2">
                <ShieldAlert size={14} className="text-electric-red" />
                Real-Time Intercepts
              </h2>
              <span className="text-[10px] font-mono text-neon-cyan/50">ACTIVE_GRID</span>
            </div>
            
            <div className="space-y-3 overflow-y-auto flex-1 pr-2 custom-scrollbar">
              <AnimatePresence mode="popLayout">
                {recentFrauds.map((tx) => (
                  <motion.div 
                    key={tx.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="p-4 bg-white/[0.03] border border-white/[0.08] rounded-xl hover:bg-white/[0.06] transition-all group"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <div className="text-xs font-bold text-white group-hover:text-neon-cyan transition-colors">{tx.city} Sector</div>
                      <div className="text-electric-red font-bold font-mono">₹{tx.amount.toLocaleString('en-IN')}</div>
                    </div>
                    <div className="flex justify-between items-center text-[10px] font-mono text-white/40">
                      <span>CARD: {tx.cardNumber}</span>
                      <span>IP: {tx.ip}</span>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>

          <div className="mt-auto space-y-4 pt-6 border-t border-white/5">
            <form onSubmit={handleSearch} className="relative">
               <input 
                type="text"
                placeholder="Query Sector (e.g. Nellore)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-black/60 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-sm text-white focus:outline-none focus:border-neon-cyan/50 transition-all placeholder:text-white/20"
               />
               <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-white/20" size={16} />
            </form>

            <AnimatePresence>
              {aiAnalysis && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 bg-neon-cyan/10 border border-neon-cyan/20 rounded-xl relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 p-2 opacity-20"><Bot size={40} /></div>
                  <p className="text-[11px] leading-relaxed text-white/80 italic relative z-10">
                    "{aiAnalysis}"
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Real-Time World Map Container */}
        <div className="flex-1 relative bg-[#AAD3DF]">
          <div ref={mapContainerRef} className="w-full h-full z-0" />
          
          {/* Footer Info (Matching Reference Style) */}
          <div className="absolute bottom-0 left-0 right-0 h-24 bg-[#FFEB3B] border-t-2 border-dashed border-black z-10 flex items-center px-10 justify-between">
            <div className="flex items-center gap-10">
              <div className="flex flex-col">
                <div className="h-10 w-16 bg-[#FF9800] border border-black flex items-center justify-center">
                  <div className="w-10 h-6 bg-white relative">
                    <div className="absolute top-0 left-0 w-full h-1/3 bg-[#FF9933]" />
                    <div className="absolute bottom-0 left-0 w-full h-1/3 bg-[#128807]" />
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full border border-blue-900" />
                  </div>
                </div>
              </div>
              <div className="flex gap-4 opacity-50">
                 <div className="h-12 w-8 bg-black/10 rounded-t-lg" />
                 <div className="h-12 w-10 bg-black/10 rounded-t-lg" />
                 <div className="h-12 w-12 bg-black/10 rounded-t-lg" />
                 <div className="h-12 w-14 bg-black/10 rounded-t-lg" />
              </div>
            </div>
            <div className="text-6xl font-black text-white drop-shadow-[2px_2px_0_rgba(0,0,0,0.2)] italic tracking-tighter">
              INDIA
            </div>
          </div>
          
          <div className="absolute top-6 right-6 z-10 flex flex-col gap-4 items-end pointer-events-none">
            <div className="glass-panel px-4 py-2 rounded-lg bg-white/90 border border-black/10 flex items-center gap-3">
              <div className="flex flex-col items-end">
                <span className="text-[10px] text-black/40 uppercase font-mono">Neural Confidence</span>
                <span className="text-sm font-bold text-black tracking-wider">99.8% ACCURACY</span>
              </div>
            </div>
          </div>

          <div className="absolute inset-0 border-[2px] border-black/5 pointer-events-none z-10" />
        </div>
      </div>
    </div>
  );
}
