import { Navbar } from "@/components/layout/Navbar";
import { MessageCircle, Send, User, Bot, Sparkles, ShieldAlert, CheckCircle } from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import gridBg from "@/assets/images/grid-bg.png";
import { cn } from "@/lib/utils";

export default function ChatPage() {
  const [messages, setMessages] = useState([
    { 
      role: "bot", 
      content: "System initialized. I am the Sentinel Fraud Response AI. I monitor incoming transaction vectors and provide immediate protocols for threat mitigation. How should we proceed?" 
    }
  ]);
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (!input.trim()) return;
    const userMsg = { role: "user", content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    
    // Intelligent response logic based on fraud queries
    setTimeout(() => {
      let botResponse = "";
      const lowerInput = input.toLowerCase();
      
      if (lowerInput.includes("fraud") || lowerInput.includes("threat")) {
        botResponse = "I have identified the recent surge in regional fraud vectors. Actions: 1. Isolate the source IP range. 2. Implement 3D-Secure for all transactions over ₹5,000. 3. Flag merchant ID for velocity review. Protocol Delta-9 active.";
      } else if (lowerInput.includes("action") || lowerInput.includes("what to do")) {
        botResponse = "Immediate action protocol: Block all incoming traffic from flagged botnet IPs, initiate refund for high-risk pending transactions, and notify the security clearinghouse. I am currently running a neural sweep on the Padugupadu sector.";
      } else {
        botResponse = "Analyzing pattern... Based on neural telemetry, I recommend maintaining high-sensitivity filters for UPI transactions. Would you like me to generate a detailed threat report for this sector?";
      }

      setMessages(prev => [...prev, { 
        role: "bot", 
        content: botResponse 
      }]);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden relative">
      <div 
        className="fixed inset-0 z-0 opacity-40 pointer-events-none mix-blend-screen"
        style={{
          backgroundImage: `url(${gridBg})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />
      <Navbar />

      <main className="relative z-10 pt-24 px-6 pb-6 max-w-5xl mx-auto h-[calc(100vh-2rem)] flex flex-col">
        <div className="grid grid-cols-12 gap-6 h-full">
          {/* Chat Interface */}
          <div className="col-span-12 lg:col-span-8 glass-panel rounded-2xl overflow-hidden flex flex-col border-neon-cyan/20">
            <div className="p-4 border-b border-white/[0.08] bg-white/[0.02] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-neon-cyan/20 flex items-center justify-center border border-neon-cyan/30">
                  <Bot className="h-6 w-6 text-neon-cyan" />
                </div>
                <div>
                  <h2 className="font-display font-bold text-white tracking-wide">SENTINEL AI BOT</h2>
                  <div className="flex items-center gap-2 text-[10px] font-mono text-neon-cyan uppercase">
                    <span className="h-1.5 w-1.5 rounded-full bg-neon-cyan animate-pulse" />
                    Threat Analysis Online
                  </div>
                </div>
              </div>
              <Sparkles className="h-5 w-5 text-amber animate-pulse" />
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
              <AnimatePresence>
                {messages.map((msg, i) => (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    key={i}
                    className={cn(
                      "flex gap-4 max-w-[85%]",
                      msg.role === "user" ? "ml-auto flex-row-reverse" : ""
                    )}
                  >
                    <div className={cn(
                      "h-8 w-8 rounded-full flex items-center justify-center shrink-0 border shadow-sm",
                      msg.role === "user" ? "bg-white/10 border-white/20" : "bg-neon-cyan/10 border-neon-cyan/20"
                    )}>
                      {msg.role === "user" ? <User size={14} className="text-white" /> : <Bot size={14} className="text-neon-cyan" />}
                    </div>
                    <div className={cn(
                      "p-4 rounded-2xl text-sm leading-relaxed",
                      msg.role === "user" 
                        ? "bg-neon-cyan/20 text-white border border-neon-cyan/30 rounded-tr-none" 
                        : "bg-white/5 text-white/90 border border-white/10 rounded-tl-none"
                    )}>
                      {msg.content}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            <div className="p-4 border-t border-white/[0.08] bg-white/[0.02]">
              <div className="relative">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSend()}
                  placeholder="Query AI for threat response actions..."
                  className="w-full bg-black/40 border border-white/10 rounded-xl pl-4 pr-12 py-4 text-white placeholder:text-muted-foreground focus:outline-none focus:border-neon-cyan/50 transition-colors"
                />
                <button 
                  onClick={handleSend}
                  className="absolute right-3 top-1/2 -translate-y-1/2 h-10 w-10 rounded-lg bg-neon-cyan flex items-center justify-center text-black hover:bg-white transition-colors"
                >
                  <Send size={18} />
                </button>
              </div>
            </div>
          </div>

          {/* Action Protocols Sidebar */}
          <div className="hidden lg:flex lg:col-span-4 flex-col gap-4">
            <div className="glass-panel p-6 rounded-2xl border-white/10">
              <h3 className="text-xs font-mono text-neon-cyan uppercase tracking-widest mb-4 flex items-center gap-2">
                <ShieldAlert className="h-4 w-4" />
                Response Protocols
              </h3>
              <div className="space-y-3">
                <div className="p-3 bg-white/5 border border-white/5 rounded-lg">
                  <div className="text-[10px] text-muted-foreground uppercase mb-1">P-01</div>
                  <div className="text-xs text-white font-medium">Auto-Refund Fraud Vectors</div>
                </div>
                <div className="p-3 bg-white/5 border border-white/5 rounded-lg">
                  <div className="text-[10px] text-muted-foreground uppercase mb-1">P-02</div>
                  <div className="text-xs text-white font-medium">IP Range Geo-Locking</div>
                </div>
                <div className="p-3 bg-electric-red/10 border border-electric-red/20 rounded-lg">
                  <div className="text-[10px] text-electric-red uppercase mb-1">P-03</div>
                  <div className="text-xs text-white font-medium">Sector Isolation Mode</div>
                </div>
              </div>
            </div>

            <div className="glass-panel p-6 rounded-2xl border-white/10 flex-1">
              <h3 className="text-xs font-mono text-white/50 uppercase tracking-widest mb-4 flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-neon-cyan" />
                Resolved Threats
              </h3>
              <div className="space-y-2 opacity-60">
                <div className="text-[10px] font-mono text-white/40">09:12 - BOTNET_NY_LOCKED</div>
                <div className="text-[10px] font-mono text-white/40">08:45 - PADUGUPADU_SECURED</div>
                <div className="text-[10px] font-mono text-white/40">07:22 - NELLORE_VELOCITY_FIX</div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
