import { Navbar } from "@/components/layout/Navbar";
import FraudGraph from "@/components/dashboard/FraudGraph";
import { StatCard } from "@/components/dashboard/StatCard";
import { TransactionList, Transaction } from "@/components/dashboard/TransactionList";
import { TransactionDetail } from "@/components/dashboard/TransactionDetail";
import { ShieldAlert, Activity, Lock, Globe } from "lucide-react";
import gridBg from "@/assets/images/grid-bg.png";
import { useState } from "react";
import { AnimatePresence } from "framer-motion";

export default function Dashboard() {
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden relative">
      <div 
        className="fixed inset-0 z-0 opacity-40 pointer-events-none mix-blend-screen"
        style={{
          backgroundImage: `url(${gridBg})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />
      
      <div className="fixed inset-0 z-0 bg-radial-gradient from-transparent via-background/50 to-background pointer-events-none" />

      <Navbar />

      <main className="relative z-10 pt-24 px-6 pb-10 max-w-[1600px] mx-auto grid grid-cols-12 gap-6 h-[calc(100vh-6rem)]">
        
        {/* Left Column: Stats & Alerts */}
        <div className="col-span-12 lg:col-span-3 flex flex-col gap-6">
          <StatCard 
            label="Security Score"
            value="98.2"
            trend="0.4%"
            trendUp={true}
            status="normal"
            icon={<ShieldAlert className="text-neon-cyan h-6 w-6" />}
            className="border-neon-cyan/20"
          />
          
          <StatCard 
            label="Threat Level"
            value="HIGH"
            status="critical"
            icon={<Activity className="text-electric-red h-6 w-6" />}
          />

          <div className="glass-panel p-6 rounded-xl flex-1 flex flex-col gap-4">
            <h3 className="font-display font-bold text-white text-lg flex items-center gap-2">
              <Lock className="h-4 w-4 text-neon-cyan" />
              SYSTEM STATUS
            </h3>
            
            <div className="space-y-4">
              <div className="space-y-1">
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>API Latency</span>
                  <span className="text-neon-cyan">12ms</span>
                </div>
                <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full w-[20%] bg-neon-cyan shadow-[0_0_10px_#00F6FF]" />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>Fraud Engine</span>
                  <span className="text-neon-cyan">Active</span>
                </div>
                <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full w-[98%] bg-neon-cyan shadow-[0_0_10px_#00F6FF]" />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>Global Nodes</span>
                  <span className="text-amber">Syncing</span>
                </div>
                <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full w-[60%] bg-amber shadow-[0_0_10px_#FFB020]" />
                </div>
              </div>
            </div>
            
            <div className="mt-auto p-4 rounded bg-electric-red/10 border border-electric-red/30">
              <div className="text-electric-red font-bold text-sm mb-1">ALERT DETECTED</div>
              <p className="text-xs text-white/70">Unusual velocity detected from IP Range 10.x.x.x (South Asia Sector).</p>
            </div>
          </div>
        </div>

        {/* Center Column: Network Topology */}
        <div className="col-span-12 lg:col-span-6 flex flex-col gap-6 relative">
          <div className="glass-panel rounded-xl overflow-hidden flex-1 relative border-neon-cyan/30 shadow-[0_0_30px_-10px_rgba(0,246,255,0.15)]">
            <div className="absolute top-4 left-0 right-0 z-10 flex justify-center pointer-events-none">
              <div className="bg-background/80 backdrop-blur px-4 py-1 rounded-full border border-neon-cyan/30">
                <span className="text-neon-cyan font-mono text-sm tracking-widest uppercase">Network Topology Grid</span>
              </div>
            </div>
            <FraudGraph />
            
            <div className="absolute bottom-6 left-6 right-6 flex justify-between items-end z-10 pointer-events-none">
               <div className="text-xs font-mono text-muted-foreground uppercase">
                  Active Nodes: 4,891<br/>
                  Live Links: 15,002<br/>
                  Currency: INR (₹)
               </div>
               <div className="flex gap-2 pointer-events-auto">
                 <button className="bg-white/10 hover:bg-white/20 p-2 rounded text-white transition-colors"><Globe className="h-4 w-4" /></button>
                 <button className="bg-white/10 hover:bg-white/20 p-2 rounded text-white transition-colors"><Activity className="h-4 w-4" /></button>
               </div>
            </div>
          </div>
        </div>

        {/* Right Column: Transaction Feed */}
        <div className="col-span-12 lg:col-span-3 h-full overflow-hidden">
          <TransactionList onSelect={setSelectedTx} />
        </div>

      </main>

      <AnimatePresence>
        {selectedTx && (
          <TransactionDetail 
            transaction={selectedTx} 
            onClose={() => setSelectedTx(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}
