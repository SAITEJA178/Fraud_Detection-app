import { Link } from "wouter";
import { AlertTriangle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-neon-cyan/5 rounded-full blur-[100px]" />
      </div>

      <div className="glass-panel p-12 rounded-2xl flex flex-col items-center text-center max-w-md relative z-10 border-electric-red/30">
        <AlertTriangle className="h-16 w-16 text-electric-red mb-6 animate-pulse" />
        
        <h1 className="text-4xl font-display font-bold text-white mb-2 tracking-wider">404</h1>
        <h2 className="text-xl text-muted-foreground mb-6 font-mono">SECTOR NOT FOUND</h2>
        
        <p className="text-sm text-muted-foreground/80 mb-8 leading-relaxed">
          The requested data node does not exist in the current sector. 
          Return to the command center immediately.
        </p>

        <Link href="/">
          <a className="bg-neon-cyan/10 hover:bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/50 px-8 py-3 rounded font-display font-bold tracking-wide transition-all hover:shadow-[0_0_20px_rgba(0,246,255,0.3)]">
            RETURN TO BASE
          </a>
        </Link>
      </div>
    </div>
  );
}
