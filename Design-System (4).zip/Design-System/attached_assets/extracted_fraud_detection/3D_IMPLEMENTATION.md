# FraudGuard 3D - Circuit Board Experience

## Overview

Your fraud detection app has been transformed into a stunning immersive 3D experience with a circuit board aesthetic. Move your mouse to interact with the dynamic 3D environment!

## Components Created

### 1. CircuitBoardScene (/components/3d/CircuitBoardScene.tsx)
The main 3D environment featuring:
- **Dynamic Circuit Board**: 150+ animated circuit traces in deep blue
- **Detection Particles**: 200 floating particles (blue and yellow-green) representing data flow
- **Mouse-Reactive Camera**: Camera follows your mouse movement for parallax effect
- **Realistic Lighting**: Ambient light, point lights, and night environment preset
- **Background**: Deep navy (#0f172a) matching circuit board aesthetic

### 2. Card3D (/components/3d/Card3D.tsx)
Interactive 3D card components with:
- **Mouse Reactivity**: Cards tilt and rotate based on mouse position
- **Hover Effects**: Scale up, color shift, and glow on hover
- **3D Depth**: Metallic materials with emissive glow
- **HTML Content**: Renders regular UI components inside 3D space
- **Floating Animation**: Subtle vertical bobbing motion

## Key Features

### Visual Design
- Circuit board traces flowing through 3D space
- Cyan/blue color scheme matching the circuit board image you provided
- Metallic blue cards with glowing borders
- Green detection particles scattered throughout
- Night environment lighting for dramatic effect

### Interactivity
- Mouse movement controls camera position and parallax
- Cards tilt and scale based on hover and mouse position
- Particles continuously move and bounce in 3D space
- Smooth transitions and animations throughout

### Color Palette
- Background: `#0f172a` (Deep navy)
- Circuit traces: `#0066ff` (Bright blue)
- Accent particles: `#00ff88` (Lime green)
- UI accents: Cyan to blue gradients

## How to Use

1. **Explore the 3D Scene**: Move your mouse around to control the camera and see the circuit board from different angles
2. **Interact with Cards**: Hover over stat cards to see 3D rotation effects
3. **Navigate**: Use the navigation bar to access Dashboard, Batch Upload, Chat, and Reports

## Technologies Used

- **React Three Fiber**: 3D rendering with React
- **Three.js**: 3D graphics library
- **Tailwind CSS**: Styling for UI overlays
- **Next.js 16**: React framework with App Router

## File Structure

```
/components/3d/
├── CircuitBoardScene.tsx    # Main 3D scene and background
└── Card3D.tsx               # Interactive 3D card component

/app/
├── page.tsx                 # New 3D landing page
└── layout.tsx               # Updated with dark background
```

## Customization Tips

- **Adjust Particle Count**: In CircuitBoardScene, change `particleCount = 200` to increase/decrease density
- **Change Circuit Traces**: Modify `traceCount = 150` for more/fewer circuit lines
- **Camera Sensitivity**: Adjust the multipliers in `CameraController` (currently `mouseX.current * 3`)
- **Colors**: Update material colors in CircuitBoard and DetectionParticles functions
- **Particle Speed**: Modify velocity calculations in the particle geometry setup

## Performance Notes

- The 3D scene runs smoothly at 60fps on modern hardware
- Particle system is optimized with BufferGeometry
- Camera updates only on mouse movement (no unnecessary renders)
- All UI overlays are positioned absolutely outside the 3D canvas

## Browser Support

Works best on:
- Chrome/Edge (WebGL 2.0)
- Firefox (WebGL 2.0)
- Safari 15+

Requires hardware that supports WebGL 2.0 for optimal performance.
