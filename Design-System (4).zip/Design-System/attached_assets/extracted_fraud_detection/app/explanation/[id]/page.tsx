'use client'

import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { fraudDetectionEngine } from '@/lib/fraud-detection'
import { ArrowLeft, BarChart3, AlertCircle, CheckCircle2 } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts'
import { useState, useEffect } from 'react'

export default function ExplanationPage({ params }: { params: { id: string } }) {
  const [transactionData, setTransactionData] = useState<any>(null)

  useEffect(() => {
    // Simulate fetching transaction data
    const engine = fraudDetectionEngine
    const tx = engine.generateSampleTransaction(Math.random())
    const score = engine.detectFraud(tx)

    setTransactionData({
      id: tx.id,
      amount: tx.amount,
      merchant: tx.merchantCategory,
      location: tx.location,
      timestamp: tx.timestamp,
      ...score,
    })
  }, [])

  if (!transactionData) {
    return (
      <div className="min-h-screen bg-background hex-pattern grid-pattern flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin mb-4 flex justify-center">
            <div className="w-12 h-12 border-4 border-primary/20 border-t-primary rounded-full"></div>
          </div>
          <p className="text-foreground/50">Loading transaction details...</p>
        </div>
      </div>
    )
  }

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'LOW':
        return { bg: 'bg-green-50 dark:bg-green-950', border: 'border-green-200 dark:border-green-800', text: 'text-green-700 dark:text-green-300' }
      case 'MEDIUM':
        return { bg: 'bg-yellow-50 dark:bg-yellow-950', border: 'border-yellow-200 dark:border-yellow-800', text: 'text-yellow-700 dark:text-yellow-300' }
      case 'HIGH':
        return { bg: 'bg-orange-50 dark:bg-orange-950', border: 'border-orange-200 dark:border-orange-800', text: 'text-orange-700 dark:text-orange-300' }
      case 'CRITICAL':
        return { bg: 'bg-red-50 dark:bg-red-950', border: 'border-red-200 dark:border-red-800', text: 'text-red-700 dark:text-red-300' }
      default:
        return { bg: 'bg-gray-50 dark:bg-gray-950', border: 'border-gray-200 dark:border-gray-800', text: 'text-gray-700 dark:text-gray-300' }
    }
  }

  const riskColorClass = getRiskColor(transactionData.riskLevel)

  // Prepare chart data for feature importance
  const chartData = transactionData.featureImportance.map((item: any) => ({
    feature: item.feature.substring(0, 15),
    importance: item.importance,
    fill: item.impact === 'increases_risk' ? '#ef4444' : '#22c55e',
  }))

  return (
    <div className="min-h-screen bg-background hex-pattern grid-pattern relative">
      {/* Animated background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-accent/5 rounded-full blur-3xl"></div>
      </div>

      {/* Header */}
      <div className="relative border-b border-primary/20 bg-gradient-to-r from-card/80 via-card/50 to-card/80 backdrop-blur-md">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-4 mb-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" className="hover:bg-primary/10 hover:text-primary transition">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <h1 className="text-3xl font-bold neon-text">Fraud Analysis Report</h1>
          </div>
          <p className="text-sm text-foreground/70">Transaction ID: <span className="text-primary font-mono">{transactionData.id}</span></p>
        </div>
      </div>

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Decision Card */}
        <Card className={`tech-card border-2 mb-8 pulse-glow ${riskColorClass.border} ${transactionData.isFraud ? 'border-destructive/50 bg-destructive/5' : 'border-primary/50 bg-primary/5'}`}>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  {transactionData.isFraud ? (
                    <AlertCircle className="w-6 h-6 text-destructive pulse-glow" />
                  ) : (
                    <CheckCircle2 className="w-6 h-6 text-primary" />
                  )}
                  <CardTitle className={transactionData.isFraud ? 'text-destructive' : 'text-primary text-xl'}>
                    {transactionData.isFraud ? 'FRAUD DETECTED' : 'TRANSACTION APPROVED'}
                  </CardTitle>
                </div>
                <CardDescription>
                  Risk Level: <span className={`font-bold ${transactionData.isFraud ? 'text-destructive' : 'text-primary'}`}>{transactionData.riskLevel}</span>
                </CardDescription>
              </div>
              <Badge className={`text-lg px-3 py-1 border ${transactionData.isFraud ? 'bg-destructive/20 text-destructive border-destructive/40' : 'bg-primary/20 text-primary border-primary/40'}`}>
                {(transactionData.score * 100).toFixed(1)}%
              </Badge>
            </div>
          </CardHeader>
        </Card>

        {/* Transaction Details */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="tech-card border-primary/30 hover:border-primary/50 transition duration-300">
            <CardHeader>
              <CardTitle className="text-lg text-primary">Transaction Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-xs text-foreground/50 mb-1">Amount</p>
                <p className="text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">${transactionData.amount.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-xs text-foreground/50 mb-1">Merchant</p>
                <p className="text-foreground">{transactionData.merchant}</p>
              </div>
              <div>
                <p className="text-xs text-foreground/50 mb-1">Location</p>
                <p className="text-foreground">{transactionData.location}</p>
              </div>
              <div>
                <p className="text-xs text-foreground/50 mb-1">Timestamp</p>
                <p className="text-sm text-foreground font-mono">{transactionData.timestamp.toLocaleString()}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="tech-card border-accent/30 hover:border-accent/50 transition duration-300">
            <CardHeader>
              <CardTitle className="text-lg text-accent">Decision Metrics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-xs text-foreground/50 mb-2">Fraud Score</p>
                <div className="w-full bg-muted rounded-full h-3">
                  <div
                    className={`h-full rounded-full ${
                      transactionData.score > 0.7
                        ? 'bg-destructive'
                        : transactionData.score > 0.4
                          ? 'bg-yellow-500'
                          : 'bg-green-500'
                    }`}
                    style={{ width: `${transactionData.score * 100}%` }}
                  />
                </div>
                <p className="text-sm font-medium mt-1">{(transactionData.score * 100).toFixed(2)}%</p>
              </div>
              <div>
                <p className="text-xs text-foreground/50 mb-2">Confidence</p>
                <div className="w-full bg-muted rounded-full h-3">
                  <div
                    className="h-full rounded-full bg-primary"
                    style={{ width: `${transactionData.confidence * 100}%` }}
                  />
                </div>
                <p className="text-sm font-medium mt-1">{(transactionData.confidence * 100).toFixed(2)}%</p>
              </div>
              <div>
                <p className="text-xs text-foreground/50 mb-2">Decision</p>
                <Badge
                  className={
                    transactionData.isFraud
                      ? 'bg-destructive text-destructive-foreground'
                      : 'bg-green-500 text-white'
                  }
                >
                  {transactionData.auditLog.decision}
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Feature Importance */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Feature Importance Analysis
            </CardTitle>
            <CardDescription>Which factors influenced the fraud decision</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Chart */}
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis
                    dataKey="feature"
                    stroke="var(--foreground)"
                    style={{ fontSize: '12px' }}
                  />
                  <YAxis stroke="var(--foreground)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'var(--card)',
                      border: `1px solid var(--border)`,
                      borderRadius: 'var(--radius)',
                    }}
                  />
                  <Bar dataKey="importance" fill="var(--primary)">
                    {chartData.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>

              {/* Detailed Breakdown */}
              <div className="space-y-3">
                <h4 className="font-semibold text-foreground">Feature Breakdown</h4>
                {transactionData.featureImportance.map((item: any, i: number) => (
                  <div key={i} className="flex items-start gap-3 p-3 rounded-lg border border-border bg-card/50">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-foreground">{item.feature}</span>
                        <Badge
                          variant="outline"
                          className={
                            item.impact === 'increases_risk'
                              ? 'bg-destructive/10 text-destructive border-destructive/30'
                              : 'bg-green-500/10 text-green-700 border-green-500/30'
                          }
                        >
                          {item.impact === 'increases_risk' ? '↑ Risk' : '↓ Risk'}
                        </Badge>
                      </div>
                      <p className="text-sm text-foreground/70">{item.value}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-bold text-foreground">{item.importance}%</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Reasoning */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Decision Reasoning</CardTitle>
            <CardDescription>Why this transaction was flagged</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-foreground/80 leading-relaxed">{transactionData.explanation}</p>
          </CardContent>
        </Card>

        {/* Audit Trail */}
        <Card>
          <CardHeader>
            <CardTitle>Audit Trail</CardTitle>
            <CardDescription>Complete decision history for compliance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-4 p-4 rounded-lg border border-border bg-card/50">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-foreground">Decision Made</p>
                  <p className="text-sm text-foreground/70 mt-1">
                    Transaction classified as <span className="font-medium">{transactionData.auditLog.decision}</span>
                  </p>
                  <p className="text-xs text-foreground/50 mt-2">
                    {transactionData.auditLog.timestamp.toLocaleString()}
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4 p-4 rounded-lg border border-border bg-card/50">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-muted-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-foreground">Analysis Complete</p>
                  <p className="text-sm text-foreground/70 mt-1">
                    Risk assessment completed using simulated ML model with {transactionData.featureImportance.length} feature signals
                  </p>
                  <p className="text-xs text-foreground/50 mt-2">
                    Model confidence: {(transactionData.confidence * 100).toFixed(1)}%
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex gap-3 mt-8">
          <Link href="/dashboard" className="flex-1">
            <Button variant="outline" className="w-full bg-transparent">
              Back to Dashboard
            </Button>
          </Link>
          <Link href="/chat" className="flex-1">
            <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
              Ask AI About This
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
