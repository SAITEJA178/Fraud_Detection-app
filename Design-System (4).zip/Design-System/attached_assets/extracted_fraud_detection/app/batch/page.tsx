'use client'

import React from "react"

import { useState } from 'react'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { fraudDetectionEngine } from '@/lib/fraud-detection'
import { ArrowLeft, Upload, Download, FileUp, CheckCircle2, AlertTriangle, Loader2 } from 'lucide-react'
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

interface BatchResult {
  totalTransactions: number
  fraudDetected: number
  approvedTransactions: number
  fraudRate: number
  avgRiskScore: number
  riskBreakdown: {
    LOW: number
    MEDIUM: number
    HIGH: number
    CRITICAL: number
  }
  results: Array<{
    id: string
    amount: number
    merchant: string
    riskLevel: string
    isFraud: boolean
  }>
}

export default function BatchPage() {
  const [isProcessing, setIsProcessing] = useState(false)
  const [batchResults, setBatchResults] = useState<BatchResult | null>(null)
  const [uploadedFileName, setUploadedFileName] = useState<string>('')

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setUploadedFileName(file.name)
    setIsProcessing(true)

    // Simulate file processing
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const engine = fraudDetectionEngine
    const numTransactions = 100

    const results = []
    let totalRiskScore = 0
    const riskBreakdown = { LOW: 0, MEDIUM: 0, HIGH: 0, CRITICAL: 0 }

    for (let i = 0; i < numTransactions; i++) {
      const transaction = engine.generateSampleTransaction(i)
      const fraudScore = engine.detectFraud(transaction)

      results.push({
        id: transaction.id,
        amount: transaction.amount,
        merchant: transaction.merchantCategory,
        riskLevel: fraudScore.riskLevel,
        isFraud: fraudScore.isFraud,
      })

      totalRiskScore += fraudScore.score
      riskBreakdown[fraudScore.riskLevel]++
    }

    const fraudCount = results.filter((r) => r.isFraud).length

    setBatchResults({
      totalTransactions: numTransactions,
      fraudDetected: fraudCount,
      approvedTransactions: numTransactions - fraudCount,
      fraudRate: (fraudCount / numTransactions) * 100,
      avgRiskScore: totalRiskScore / numTransactions,
      riskBreakdown,
      results,
    })

    setIsProcessing(false)
  }

  const downloadResults = () => {
    if (!batchResults) return

    const csv = [
      ['Transaction ID', 'Amount', 'Merchant', 'Risk Level', 'Fraud Status'],
      ...batchResults.results.map((r) => [
        r.id,
        `$${r.amount.toFixed(2)}`,
        r.merchant,
        r.riskLevel,
        r.isFraud ? 'FRAUD' : 'APPROVED',
      ]),
    ]
      .map((row) => row.join(','))
      .join('\n')

    const element = document.createElement('a')
    element.setAttribute('href', `data:text/csv;charset=utf-8,${encodeURIComponent(csv)}`)
    element.setAttribute('download', `fraud-analysis-${new Date().toISOString().split('T')[0]}.csv`)
    element.style.display = 'none'
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  const riskChartData = batchResults
    ? [
        { name: 'Low Risk', value: batchResults.riskBreakdown.LOW, color: '#22c55e' },
        { name: 'Medium Risk', value: batchResults.riskBreakdown.MEDIUM, color: '#eab308' },
        { name: 'High Risk', value: batchResults.riskBreakdown.HIGH, color: '#f97316' },
        { name: 'Critical Risk', value: batchResults.riskBreakdown.CRITICAL, color: '#ef4444' },
      ]
    : []

  return (
    <div className="min-h-screen bg-background hex-pattern grid-pattern relative">
      {/* Animated background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 right-1/3 w-96 h-96 bg-primary/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/3 left-1/3 w-96 h-96 bg-accent/5 rounded-full blur-3xl"></div>
      </div>

      {/* Header */}
      <div className="relative border-b border-primary/20 bg-gradient-to-r from-card/80 via-card/50 to-card/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="hover:bg-primary/10 hover:text-primary transition">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </Link>
          <h1 className="text-3xl font-bold neon-text">Batch Processing</h1>
        </div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Upload Section */}
        <Card className="tech-card border-primary/30 hover:border-primary/50 transition duration-300 mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="w-5 h-5 text-primary" />
              <span className="text-primary">Upload CSV File</span>
            </CardTitle>
            <CardDescription>Process historical transaction data in batch</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="border-2 border-dashed border-primary/30 rounded-lg p-8 text-center hover:border-primary/60 hover:bg-primary/5 transition duration-300">
                <input
                  type="file"
                  accept=".csv"
                  onChange={handleFileUpload}
                  disabled={isProcessing}
                  className="hidden"
                  id="csv-upload"
                />
                <label htmlFor="csv-upload" className="cursor-pointer block">
                  <FileUp className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                  <p className="text-foreground font-medium mb-1">Click to upload CSV</p>
                  <p className="text-sm text-foreground/50">Expected columns: amount, merchant, location, device_new</p>
                </label>
              </div>

              {uploadedFileName && (
                <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                  <p className="text-sm text-foreground/70">
                    Processing: <span className="font-medium text-primary">{uploadedFileName}</span>
                  </p>
                </div>
              )}

              {isProcessing && (
                <div className="flex items-center justify-center gap-2 py-4">
                  <Loader2 className="w-5 h-5 animate-spin text-primary" />
                  <span className="text-foreground/70">Processing transactions...</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Results Section */}
        {batchResults && (
          <>
            {/* Summary Stats */}
            <div className="grid md:grid-cols-5 gap-4 mb-8">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-foreground/70">Total Processed</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-foreground">{batchResults.totalTransactions}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-foreground/70">Fraud Detected</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-baseline gap-2">
                    <div className="text-2xl font-bold text-destructive">{batchResults.fraudDetected}</div>
                    <AlertTriangle className="w-4 h-4 text-destructive" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-foreground/70">Approved</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-baseline gap-2">
                    <div className="text-2xl font-bold text-green-600">{batchResults.approvedTransactions}</div>
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-foreground/70">Fraud Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-foreground">{batchResults.fraudRate.toFixed(1)}%</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-foreground/70">Avg Risk Score</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-foreground">{batchResults.avgRiskScore.toFixed(2)}</div>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid lg:grid-cols-2 gap-6 mb-8">
              <Card>
                <CardHeader>
                  <CardTitle>Risk Distribution</CardTitle>
                  <CardDescription>Breakdown by risk level</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={riskChartData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={2}
                        dataKey="value"
                      >
                        {riskChartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'var(--card)',
                          border: `1px solid var(--border)`,
                          borderRadius: 'var(--radius)',
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Risk Level Count</CardTitle>
                  <CardDescription>Number of transactions per risk level</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart
                      data={[
                        { name: 'LOW', count: batchResults.riskBreakdown.LOW, fill: '#22c55e' },
                        { name: 'MEDIUM', count: batchResults.riskBreakdown.MEDIUM, fill: '#eab308' },
                        { name: 'HIGH', count: batchResults.riskBreakdown.HIGH, fill: '#f97316' },
                        { name: 'CRITICAL', count: batchResults.riskBreakdown.CRITICAL, fill: '#ef4444' },
                      ]}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                      <XAxis stroke="var(--foreground)" />
                      <YAxis stroke="var(--foreground)" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'var(--card)',
                          border: `1px solid var(--border)`,
                          borderRadius: 'var(--radius)',
                        }}
                      />
                      <Bar dataKey="count" fill="var(--primary)">
                        {[
                          { fill: '#22c55e' },
                          { fill: '#eab308' },
                          { fill: '#f97316' },
                          { fill: '#ef4444' },
                        ].map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Results Table */}
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Transaction Results</CardTitle>
                <CardDescription>First 50 results from analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-3 px-4 font-semibold text-foreground">Transaction ID</th>
                        <th className="text-left py-3 px-4 font-semibold text-foreground">Amount</th>
                        <th className="text-left py-3 px-4 font-semibold text-foreground">Merchant</th>
                        <th className="text-left py-3 px-4 font-semibold text-foreground">Risk Level</th>
                        <th className="text-left py-3 px-4 font-semibold text-foreground">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {batchResults.results.slice(0, 50).map((result) => (
                        <tr key={result.id} className="border-b border-border/50 hover:bg-muted/50">
                          <td className="py-3 px-4 text-foreground/70 font-mono text-xs">
                            {result.id.slice(0, 15)}...
                          </td>
                          <td className="py-3 px-4 text-foreground font-medium">${result.amount.toFixed(2)}</td>
                          <td className="py-3 px-4 text-foreground">{result.merchant}</td>
                          <td className="py-3 px-4">
                            <Badge
                              variant="outline"
                              className={
                                result.riskLevel === 'LOW'
                                  ? 'bg-green-500/10 text-green-700 border-green-500/30'
                                  : result.riskLevel === 'MEDIUM'
                                    ? 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30'
                                    : result.riskLevel === 'HIGH'
                                      ? 'bg-orange-500/10 text-orange-700 border-orange-500/30'
                                      : 'bg-red-500/10 text-red-700 border-red-500/30'
                              }
                            >
                              {result.riskLevel}
                            </Badge>
                          </td>
                          <td className="py-3 px-4">
                            <Badge
                              className={
                                result.isFraud
                                  ? 'bg-destructive text-destructive-foreground'
                                  : 'bg-green-500 text-white'
                              }
                            >
                              {result.isFraud ? 'FRAUD' : 'APPROVED'}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            {/* Download Results */}
            <div className="flex gap-3">
              <Button onClick={downloadResults} className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90">
                <Download className="w-4 h-4 mr-2" />
                Download CSV Report
              </Button>
              <Link href="/dashboard" className="flex-1">
                <Button variant="outline" className="w-full bg-transparent">
                  Back to Dashboard
                </Button>
              </Link>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
