'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { fraudDetectionEngine, type FraudScore } from '@/lib/fraud-detection'
import { ArrowLeft, AlertTriangle, CheckCircle2, Clock, TrendingUp, Shield } from 'lucide-react'
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

interface TransactionRecord {
  id: string
  amount: number
  merchant: string
  status: 'approved' | 'blocked'
  riskLevel: string
  timestamp: Date
  fraudScore: FraudScore
}

export default function Dashboard() {
  const [transactions, setTransactions] = useState<TransactionRecord[]>([])
  const [stats, setStats] = useState({
    totalProcessed: 0,
    blocked: 0,
    fraudRate: 0,
    avgRiskScore: 0,
  })
  const [selectedTransaction, setSelectedTransaction] = useState<TransactionRecord | null>(null)

  // Simulate real-time transaction processing
  useEffect(() => {
    const interval = setInterval(() => {
      const engine = fraudDetectionEngine
      const transaction = engine.generateSampleTransaction(Math.random())
      const fraudScore = engine.detectFraud(transaction)

      const newRecord: TransactionRecord = {
        id: transaction.id,
        amount: transaction.amount,
        merchant: transaction.merchantCategory,
        status: fraudScore.isFraud ? 'blocked' : 'approved',
        riskLevel: fraudScore.riskLevel,
        timestamp: transaction.timestamp,
        fraudScore,
      }

      setTransactions((prev) => [newRecord, ...prev.slice(0, 19)])

      // Update stats
      setStats((prev) => {
        const blocked = prev.blocked + (fraudScore.isFraud ? 1 : 0)
        const total = prev.totalProcessed + 1
        const fraudRate = (blocked / total) * 100
        const avgRiskScore = (prev.avgRiskScore * prev.totalProcessed + fraudScore.score) / total

        return {
          totalProcessed: total,
          blocked,
          fraudRate: Math.round(fraudRate * 100) / 100,
          avgRiskScore: Math.round(avgRiskScore * 100) / 100,
        }
      })
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  // Chart data for fraud trends
  const fraudTrendData = [
    { time: '00:00', fraud: 2, approved: 48 },
    { time: '04:00', fraud: 3, approved: 45 },
    { time: '08:00', fraud: 4, approved: 62 },
    { time: '12:00', fraud: 8, approved: 89 },
    { time: '16:00', fraud: 5, approved: 78 },
    { time: '20:00', fraud: 7, approved: 91 },
  ]

  const riskDistribution = [
    { name: 'Low Risk', value: 65, color: '#22c55e' },
    { name: 'Medium Risk', value: 22, color: '#eab308' },
    { name: 'High Risk', value: 10, color: '#f97316' },
    { name: 'Critical Risk', value: 3, color: '#ef4444' },
  ]

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'LOW':
        return 'text-green-600 bg-green-50 border-green-200'
      case 'MEDIUM':
        return 'text-yellow-600 bg-yellow-50 border-yellow-200'
      case 'HIGH':
        return 'text-orange-600 bg-orange-50 border-orange-200'
      case 'CRITICAL':
        return 'text-red-600 bg-red-50 border-red-200'
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200'
    }
  }

  const getRiskBgColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'LOW':
        return 'bg-green-500/10 hover:bg-green-500/20'
      case 'MEDIUM':
        return 'bg-yellow-500/10 hover:bg-yellow-500/20'
      case 'HIGH':
        return 'bg-orange-500/10 hover:bg-orange-500/20'
      case 'CRITICAL':
        return 'bg-red-500/10 hover:bg-red-500/20'
      default:
        return 'bg-gray-500/10'
    }
  }

  return (
    <div className="min-h-screen bg-background hex-pattern grid-pattern relative">
      {/* Animated background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 right-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-accent/5 rounded-full blur-3xl"></div>
      </div>

      {/* Header */}
      <div className="relative border-b border-primary/20 bg-gradient-to-r from-card/80 via-card/50 to-card/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="hover:bg-primary/10 hover:text-primary transition">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <h1 className="text-3xl font-bold neon-text">Transaction Monitor</h1>
          </div>
          <Badge className="bg-primary text-primary-foreground">Live</Badge>
        </div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="tech-card border-primary/30 hover:border-primary/50 transition duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-foreground/70">Total Processed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline gap-2">
                <div className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">{stats.totalProcessed}</div>
                <TrendingUp className="w-4 h-4 text-primary animate-bounce" />
              </div>
            </CardContent>
          </Card>

          <Card className="tech-card border-destructive/30 hover:border-destructive/50 transition duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-foreground/70">Blocked Transactions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline gap-2">
                <div className="text-2xl font-bold text-destructive">{stats.blocked}</div>
                <AlertTriangle className="w-4 h-4 text-destructive pulse-glow" />
              </div>
            </CardContent>
          </Card>

          <Card className="tech-card border-accent/30 hover:border-accent/50 transition duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-foreground/70">Fraud Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline gap-2">
                <div className="text-2xl font-bold bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">{stats.fraudRate}%</div>
              </div>
            </CardContent>
          </Card>

          <Card className="tech-card border-primary/30 hover:border-primary/50 transition duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-foreground/70">Avg Risk Score</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline gap-2">
                <div className="text-2xl font-bold text-primary">{stats.avgRiskScore.toFixed(2)}</div>
                <Shield className="w-4 h-4 text-primary glow-primary" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Fraud Trends</CardTitle>
              <CardDescription>Transactions over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={fraudTrendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis stroke="var(--foreground)" />
                  <YAxis stroke="var(--foreground)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'var(--card)',
                      border: `1px solid var(--border)`,
                      borderRadius: 'var(--radius)',
                    }}
                  />
                  <Legend />
                  <Line type="monotone" dataKey="fraud" stroke="var(--destructive)" strokeWidth={2} name="Fraud Detected" />
                  <Line type="monotone" dataKey="approved" stroke="var(--primary)" strokeWidth={2} name="Approved" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Risk Distribution</CardTitle>
              <CardDescription>Current distribution</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie data={riskDistribution} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={2} dataKey="value">
                    {riskDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'var(--card)',
                      border: `1px solid var(--border)`,
                      borderRadius: 'var(--radius)',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Transactions Table */}
        <div className="grid lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Recent Transactions</CardTitle>
              <CardDescription>Last 20 transactions processed</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {transactions.length === 0 ? (
                  <p className="text-sm text-foreground/50 text-center py-8">Waiting for transactions...</p>
                ) : (
                  transactions.map((txn) => (
                    <button
                      key={txn.id}
                      onClick={() => setSelectedTransaction(txn)}
                      className={`w-full text-left p-3 rounded-lg border border-border transition ${getRiskBgColor(txn.riskLevel)}`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-foreground">{txn.merchant}</span>
                            <Badge variant="outline" className="text-xs">
                              ${txn.amount.toFixed(2)}
                            </Badge>
                          </div>
                          <div className="text-xs text-foreground/50 mt-1">
                            {txn.timestamp.toLocaleTimeString()}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className={`text-xs font-medium px-2 py-1 rounded border ${getRiskColor(txn.riskLevel)}`}>
                            {txn.riskLevel}
                          </div>
                          {txn.status === 'blocked' ? (
                            <AlertTriangle className="w-4 h-4 text-destructive" />
                          ) : (
                            <CheckCircle2 className="w-4 h-4 text-green-500" />
                          )}
                        </div>
                      </div>
                    </button>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Selected Transaction Details */}
          <Card className="h-fit">
            <CardHeader>
              <CardTitle>Transaction Details</CardTitle>
              <CardDescription>Click a transaction to view details</CardDescription>
            </CardHeader>
            <CardContent>
              {selectedTransaction ? (
                <div className="space-y-4">
                  <div>
                    <p className="text-xs text-foreground/50 mb-1">Transaction ID</p>
                    <p className="text-sm font-mono text-foreground">{selectedTransaction.id.slice(0, 20)}...</p>
                  </div>
                  <div>
                    <p className="text-xs text-foreground/50 mb-1">Risk Score</p>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div
                        className={`h-full rounded-full ${
                          selectedTransaction.fraudScore.score > 0.7
                            ? 'bg-destructive'
                            : selectedTransaction.fraudScore.score > 0.4
                              ? 'bg-yellow-500'
                              : 'bg-green-500'
                        }`}
                        style={{ width: `${selectedTransaction.fraudScore.score * 100}%` }}
                      />
                    </div>
                    <p className="text-sm font-medium mt-1">{(selectedTransaction.fraudScore.score * 100).toFixed(1)}%</p>
                  </div>
                  <div>
                    <p className="text-xs text-foreground/50 mb-1">Decision</p>
                    <Badge
                      className={
                        selectedTransaction.fraudScore.isFraud
                          ? 'bg-destructive text-destructive-foreground'
                          : 'bg-green-500 text-white'
                      }
                    >
                      {selectedTransaction.fraudScore.auditLog.decision}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-xs text-foreground/50 mb-1">Reasoning</p>
                    <p className="text-sm text-foreground/70">{selectedTransaction.fraudScore.explanation}</p>
                  </div>
                  <Link href={`/explanation/${selectedTransaction.id}`}>
                    <Button variant="outline" className="w-full mt-4 bg-transparent" size="sm">
                      View Full Analysis
                    </Button>
                  </Link>
                </div>
              ) : (
                <p className="text-sm text-foreground/50 text-center py-8">No transaction selected</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
