'use client'

import React from "react"

import { useState, useRef, useEffect } from 'react'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { ArrowLeft, Send, MessageCircle, Zap, HelpCircle, ArrowRight } from 'lucide-react'

interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
}

type ChatMode = 'expert' | 'support'

export default function ChatPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [mode, setMode] = useState<ChatMode>('support')
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // Quick question suggestions
  const suggestions = {
    expert: [
      'Explain SHAP values in fraud detection',
      'How do you handle class imbalance in fraud datasets?',
      'What is concept drift in fraud models?',
      'Describe feature engineering for transaction data',
    ],
    support: [
      'Why was my transaction blocked?',
      'How do I dispute a fraud flag?',
      'What is a risk score?',
      'How does real-time monitoring work?',
    ],
  }

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput('')
    setIsLoading(true)

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [
            ...messages.map((m) => ({
              role: m.role,
              content: m.content,
            })),
            { role: 'user', content: input },
          ],
          mode,
        }),
      })

      if (!response.ok) throw new Error('Failed to get response')

      const reader = response.body?.getReader()
      if (!reader) throw new Error('No response body')

      let assistantMessage = ''
      const assistantId = `msg-${Date.now()}`

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        const text = new TextDecoder().decode(value)
        assistantMessage += text

        setMessages((prev) => {
          const existing = prev.find((m) => m.id === assistantId)
          if (existing) {
            return prev.map((m) => (m.id === assistantId ? { ...m, content: assistantMessage } : m))
          } else {
            return [
              ...prev,
              {
                id: assistantId,
                role: 'assistant' as const,
                content: assistantMessage,
                timestamp: new Date(),
              },
            ]
          }
        })
      }
    } catch (error) {
      console.error('Chat error:', error)
      setMessages((prev) => [
        ...prev,
        {
          id: `msg-error-${Date.now()}`,
          role: 'assistant',
          content: 'I encountered an error processing your request. Please try again.',
          timestamp: new Date(),
        },
      ])
    } finally {
      setIsLoading(false)
    }
  }

  const handleSuggestion = (suggestion: string) => {
    setInput(suggestion)
  }

  return (
    <div className="min-h-screen bg-background hex-pattern grid-pattern flex flex-col relative">
      {/* Animated background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-accent/5 rounded-full blur-3xl"></div>
      </div>

      {/* Header */}
      <div className="relative border-b border-primary/20 bg-gradient-to-r from-card/80 via-card/50 to-card/80 backdrop-blur-md">
        <div className="max-w-4xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-4 mb-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="hover:bg-primary/10 hover:text-primary transition">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <h1 className="text-3xl font-bold neon-text">AI Assistant</h1>
          </div>

          {/* Mode Selector */}
          <div className="flex gap-2">
            <Button
              variant={mode === 'support' ? 'default' : 'outline'}
              size="sm"
              onClick={() => {
                setMode('support')
                setMessages([])
              }}
              className={mode === 'support' ? 'bg-gradient-to-r from-primary to-accent text-primary-foreground glow-primary' : 'border-primary/30 hover:bg-primary/10'}
            >
              <HelpCircle className="w-4 h-4 mr-1" />
              Support Mode
            </Button>
            <Button
              variant={mode === 'expert' ? 'default' : 'outline'}
              size="sm"
              onClick={() => {
                setMode('expert')
                setMessages([])
              }}
              className={mode === 'expert' ? 'bg-gradient-to-r from-accent to-primary text-primary-foreground glow-accent' : 'border-accent/30 hover:bg-accent/10'}
            >
              <Zap className="w-4 h-4 mr-1" />
              Expert Mode
            </Button>
          </div>
        </div>
      </div>

      {/* Chat Container */}
      <div className="flex-1 flex flex-col max-w-4xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Initial State with Suggestions */}
        {messages.length === 0 && (
          <div className="flex-1 flex flex-col items-center justify-center text-center mb-8">
            <MessageCircle className="w-16 h-16 text-muted-foreground mb-4 opacity-50" />
            <h2 className="text-2xl font-bold text-foreground mb-2">
              {mode === 'expert' ? 'Fraud Detection Expert' : 'Support Assistant'}
            </h2>
            <p className="text-foreground/70 mb-8 max-w-md">
              {mode === 'expert'
                ? 'Ask technical questions about fraud detection algorithms, explainable AI, and model optimization.'
                : 'Get help understanding fraud decisions, disputes, and how the system works.'}
            </p>

            {/* Suggestions */}
            <div className="space-y-3 w-full">
              <p className="text-sm text-foreground/50">Quick questions:</p>
              <div className="grid gap-2">
                {suggestions[mode].map((suggestion, i) => (
                  <button
                    key={i}
                    onClick={() => handleSuggestion(suggestion)}
                    className="tech-card text-left p-4 border-primary/30 hover:border-primary/60 transition duration-300 group"
                  >
                    <p className="text-sm font-medium text-foreground flex items-center justify-between">
                      {suggestion}
                      <ArrowRight className="w-4 h-4 text-primary group-hover:text-accent opacity-0 group-hover:opacity-100 transition translate-x-0 group-hover:translate-x-1" />
                    </p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Messages */}
        <div className="space-y-4 flex-1 mb-8">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                  message.role === 'user'
                    ? 'bg-primary text-primary-foreground rounded-br-none'
                    : 'bg-muted text-foreground rounded-bl-none'
                }`}
              >
                <p className="text-sm whitespace-pre-wrap break-words">{message.content}</p>
                <p className="text-xs opacity-70 mt-1">{message.timestamp.toLocaleTimeString()}</p>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-muted text-foreground px-4 py-3 rounded-lg rounded-bl-none">
                <div className="flex gap-2">
                  <div className="w-2 h-2 rounded-full bg-foreground/50 animate-bounce" />
                  <div className="w-2 h-2 rounded-full bg-foreground/50 animate-bounce" style={{ animationDelay: '0.2s' }} />
                  <div className="w-2 h-2 rounded-full bg-foreground/50 animate-bounce" style={{ animationDelay: '0.4s' }} />
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Form */}
        <form onSubmit={handleSendMessage} className="border-t border-border pt-4">
          <div className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={
                mode === 'expert'
                  ? 'Ask about fraud detection algorithms...'
                  : 'Ask about your transaction...'
              }
              disabled={isLoading}
              className="flex-1"
            />
            <Button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
