'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Download, TrendingUp, AlertTriangle, CheckCircle2, BarChart3, Zap } from 'lucide-react'
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts'

// Mock performance data
const performanceMetrics = {
  overall: {
    accuracy: 99.8,
    precision: 98.5,
    recall: 97.2,
    f1Score: 97.85,
    auc_roc: 99.2,
  },
  confusionMatrix: {
    truePositives: 487,
    falsePositives: 8,
    trueNegatives: 6192,
    falseNegatives: 13,
  },
  performanceByRiskLevel: [
    { level: 'LOW', accuracy: 99.9, precision: 99.8, recall: 98.5 },
    { level: 'MEDIUM', accuracy: 98.5, precision: 96.2, recall: 95.8 },
    { level: 'HIGH', accuracy: 97.2, precision: 94.1, recall: 93.5 },
    { level: 'CRITICAL', accuracy: 95.8, precision: 89.3, recall: 88.1 },
  ],
  latencyMetrics: [
    { percentile: '50th', latency: 12 },
    { percentile: '75th', latency: 18 },
    { percentile: '90th', latency: 28 },
    { percentile: '95th', latency: 42 },
    { percentile: '99th', latency: 89 },
  ],
  fraudTrendData: [
    { week: 'Week 1', detected: 45, missed: 2 },
    { week: 'Week 2', detected: 52, missed: 1 },
    { week: 'Week 3', detected: 48, missed: 3 },
    { week: 'Week 4', detected: 61, missed: 2 },
    { week: 'Week 5', detected: 58, missed: 1 },
    { week: 'Week 6', detected: 67, missed: 2 },
  ],
  conceptDriftData: [
    { month: 'Jan', modelAccuracy: 99.1, dataAccuracy: 98.9, drift: 0.2 },
    { month: 'Feb', modelAccuracy: 98.8, dataAccuracy: 98.4, drift: 0.4 },
    { month: 'Mar', modelAccuracy: 98.3, dataAccuracy: 97.8, drift: 0.5 },
    { month: 'Apr', modelAccuracy: 97.9, dataAccuracy: 97.1, drift: 0.8 },
    { month: 'May', modelAccuracy: 97.2, dataAccuracy: 96.2, drift: 1.0 },
  ],
}

export default function ReportsPage() {
  const [exportFormat, setExportFormat] = useState<'pdf' | 'csv'>('pdf')

  const handleExport = () => {
    // Simulate export
    const content = `
Fraud Detection System - Performance Evaluation Report
Generated: ${new Date().toLocaleString()}

EXECUTIVE SUMMARY
=================
Overall Accuracy: ${performanceMetrics.overall.accuracy}%
Precision: ${performanceMetrics.overall.precision}%
Recall: ${performanceMetrics.overall.recall}%
F1 Score: ${performanceMetrics.overall.f1Score}%
AUC-ROC: ${performanceMetrics.overall.auc_roc}%

CONFUSION MATRIX
================
True Positives: ${performanceMetrics.confusionMatrix.truePositives}
False Positives: ${performanceMetrics.confusionMatrix.falsePositives}
True Negatives: ${performanceMetrics.confusionMatrix.trueNegatives}
False Negatives: ${performanceMetrics.confusionMatrix.falseNegatives}

LATENCY METRICS (ms)
====================
50th percentile: ${performanceMetrics.latencyMetrics[0].latency}ms
95th percentile: ${performanceMetrics.latencyMetrics[3].latency}ms
99th percentile: ${performanceMetrics.latencyMetrics[4].latency}ms
    `

    const element = document.createElement('a')
    element.setAttribute('href', `data:text/plain;charset=utf-8,${encodeURIComponent(content)}`)
    element.setAttribute('download', `fraud-detection-report-${new Date().toISOString().split('T')[0]}.txt`)
    element.style.display = 'none'
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  return (
    <div className="min-h-screen bg-background hex-pattern grid-pattern relative">
      {/* Animated background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-40 right-40 w-96 h-96 bg-primary/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-40 left-40 w-96 h-96 bg-accent/5 rounded-full blur-3xl"></div>
      </div>

      {/* Header */}
      <div className="relative border-b border-primary/20 bg-gradient-to-r from-card/80 via-card/50 to-card/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="hover:bg-primary/10 hover:text-primary transition">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <h1 className="text-3xl font-bold neon-text">Performance Reports</h1>
          </div>
          <Button onClick={handleExport} className="bg-gradient-to-r from-primary to-accent text-primary-foreground hover:shadow-lg hover:shadow-primary/30 transition glow-primary">
            <Download className="w-4 h-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Key Metrics */}
        <div className="grid md:grid-cols-5 gap-4 mb-8">
          <Card className="tech-card border-primary/30 hover:border-primary/50 transition duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-foreground/70">Accuracy</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">{performanceMetrics.overall.accuracy}%</div>
              <p className="text-xs text-foreground/50 mt-1">Correct predictions</p>
            </CardContent>
          </Card>

          <Card className="tech-card border-accent/30 hover:border-accent/50 transition duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-foreground/70">Precision</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-accent">{performanceMetrics.overall.precision}%</div>
              <p className="text-xs text-foreground/50 mt-1">True positive rate</p>
            </CardContent>
          </Card>

          <Card className="tech-card border-primary/30 hover:border-primary/50 transition duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-foreground/70">Recall</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold bg-gradient-to-r from-secondary to-primary bg-clip-text text-transparent">{performanceMetrics.overall.recall}%</div>
              <p className="text-xs text-foreground/50 mt-1">Fraud detection rate</p>
            </CardContent>
          </Card>

          <Card className="tech-card border-accent/30 hover:border-accent/50 transition duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-foreground/70">F1 Score</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">{performanceMetrics.overall.f1Score}%</div>
              <p className="text-xs text-foreground/50 mt-1">Harmonic mean</p>
            </CardContent>
          </Card>

          <Card className="tech-card border-primary/30 hover:border-primary/50 transition duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-foreground/70">AUC-ROC</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-accent">{performanceMetrics.overall.auc_roc}%</div>
              <p className="text-xs text-foreground/50 mt-1">Model discrimination</p>
            </CardContent>
          </Card>
        </div>

        {/* Performance by Risk Level */}
        <Card className="tech-card border-primary/30 hover:border-primary/50 transition duration-300 mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-primary" />
              <span className="text-primary">Performance by Risk Level</span>
            </CardTitle>
            <CardDescription>Metrics breakdown across risk categories</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={performanceMetrics.performanceByRiskLevel}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="level" stroke="var(--foreground)" />
                <YAxis stroke="var(--foreground)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'var(--card)',
                    border: `1px solid var(--border)`,
                    borderRadius: 'var(--radius)',
                  }}
                />
                <Legend />
                <Bar dataKey="accuracy" fill="var(--primary)" name="Accuracy %" />
                <Bar dataKey="precision" fill="var(--accent)" name="Precision %" />
                <Bar dataKey="recall" fill="var(--secondary)" name="Recall %" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Latency Metrics */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5" />
              Response Time Distribution
            </CardTitle>
            <CardDescription>Latency percentiles for real-time processing</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={performanceMetrics.latencyMetrics}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="percentile" stroke="var(--foreground)" />
                <YAxis label={{ value: 'Milliseconds', angle: -90, position: 'insideLeft' }} stroke="var(--foreground)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'var(--card)',
                    border: `1px solid var(--border)`,
                    borderRadius: 'var(--radius)',
                  }}
                  formatter={(value) => `${value}ms`}
                />
                <Bar dataKey="latency" fill="var(--primary)" name="Latency (ms)" />
              </BarChart>
            </ResponsiveContainer>
            <div className="mt-4 p-4 rounded-lg bg-primary/5 border border-primary/20">
              <p className="text-sm text-foreground/70">
                <strong>Performance Note:</strong> System maintains sub-50ms median latency for real-time fraud detection, meeting stringent financial processing requirements.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Fraud Detection Trends */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Weekly Detection Trends
            </CardTitle>
            <CardDescription>Fraud detection and miss rate over time</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={performanceMetrics.fraudTrendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="week" stroke="var(--foreground)" />
                <YAxis stroke="var(--foreground)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'var(--card)',
                    border: `1px solid var(--border)`,
                    borderRadius: 'var(--radius)',
                  }}
                />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="detected"
                  stackId="1"
                  stroke="var(--primary)"
                  fill="var(--primary)"
                  name="Detected"
                  opacity={0.6}
                />
                <Area
                  type="monotone"
                  dataKey="missed"
                  stackId="1"
                  stroke="var(--destructive)"
                  fill="var(--destructive)"
                  name="Missed"
                  opacity={0.6}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Concept Drift Monitoring */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              Concept Drift Analysis
            </CardTitle>
            <CardDescription>Model accuracy degradation and drift detection</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={performanceMetrics.conceptDriftData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="month" stroke="var(--foreground)" />
                <YAxis stroke="var(--foreground)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'var(--card)',
                    border: `1px solid var(--border)`,
                    borderRadius: 'var(--radius)',
                  }}
                  formatter={(value) => `${value}%`}
                />
                <Legend />
                <Line type="monotone" dataKey="modelAccuracy" stroke="var(--primary)" strokeWidth={2} name="Model Accuracy" />
                <Line type="monotone" dataKey="dataAccuracy" stroke="var(--accent)" strokeWidth={2} name="Data Accuracy" />
              </LineChart>
            </ResponsiveContainer>
            <div className="mt-4 p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
              <p className="text-sm text-foreground/70">
                <strong>Drift Alert:</strong> Concept drift detected at 1.0%. Consider retraining model with recent data to maintain accuracy.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Confusion Matrix */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Confusion Matrix</CardTitle>
            <CardDescription>Classification results summary</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/20">
                  <p className="text-xs text-foreground/50 mb-1">True Positives</p>
                  <p className="text-2xl font-bold text-green-700">{performanceMetrics.confusionMatrix.truePositives}</p>
                  <p className="text-xs text-foreground/50 mt-1">Correctly identified fraud</p>
                </div>
                <div className="p-4 rounded-lg bg-orange-500/10 border border-orange-500/20">
                  <p className="text-xs text-foreground/50 mb-1">False Positives</p>
                  <p className="text-2xl font-bold text-orange-700">{performanceMetrics.confusionMatrix.falsePositives}</p>
                  <p className="text-xs text-foreground/50 mt-1">Legitimate flagged as fraud</p>
                </div>
              </div>
              <div className="space-y-3">
                <div className="p-4 rounded-lg bg-blue-500/10 border border-blue-500/20">
                  <p className="text-xs text-foreground/50 mb-1">True Negatives</p>
                  <p className="text-2xl font-bold text-blue-700">{performanceMetrics.confusionMatrix.trueNegatives}</p>
                  <p className="text-xs text-foreground/50 mt-1">Correctly identified legitimate</p>
                </div>
                <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/20">
                  <p className="text-xs text-foreground/50 mb-1">False Negatives</p>
                  <p className="text-2xl font-bold text-red-700">{performanceMetrics.confusionMatrix.falseNegatives}</p>
                  <p className="text-xs text-foreground/50 mt-1">Missed fraud cases</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recommendations */}
        <Card>
          <CardHeader>
            <CardTitle>Recommendations & Insights</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-3 p-4 rounded-lg bg-primary/5 border border-primary/20">
              <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-foreground">System Performance Excellent</p>
                <p className="text-sm text-foreground/70">Accuracy above 99.5% and latency within SLA targets.</p>
              </div>
            </div>

            <div className="flex gap-3 p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
              <AlertTriangle className="w-5 h-5 text-yellow-700 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-foreground">Monitor Concept Drift</p>
                <p className="text-sm text-foreground/70">Drift increasing at 0.2% monthly. Plan model retraining in next quarter.</p>
              </div>
            </div>

            <div className="flex gap-3 p-4 rounded-lg bg-blue-500/10 border border-blue-500/20">
              <CheckCircle2 className="w-5 h-5 text-blue-700 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-foreground">Regulatory Compliance</p>
                <p className="text-sm text-foreground/70">100% audit trail enabled. All decisions explainable for PCI-DSS & GDPR compliance.</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex gap-3 mt-8">
          <Link href="/dashboard" className="flex-1">
            <Button variant="outline" className="w-full bg-transparent">
              Back to Dashboard
            </Button>
          </Link>
          <Button onClick={handleExport} className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90">
            <Download className="w-4 h-4 mr-2" />
            Download Full Report
          </Button>
        </div>
      </div>
    </div>
  )
}
