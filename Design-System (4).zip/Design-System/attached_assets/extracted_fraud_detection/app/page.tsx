'use client'

import Link from 'next/link'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { AlertCircle, Zap, MessageCircle, Shield, BarChart3, FileUp } from 'lucide-react'

const AnimatedCardBackground = () => {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      <style>{`
        @keyframes moveBack {
          0% {
            transform: perspective(1000px) translateZ(0) scale(1) translateY(0);
            opacity: 0.6;
          }
          50% {
            opacity: 0.7;
            transform: perspective(1000px) translateZ(-200px) scale(0.85) translateY(20px);
          }
          100% {
            transform: perspective(1000px) translateZ(-500px) scale(0.6) translateY(40px);
            opacity: 0.3;
          }
        }
        
        @keyframes rotateCard {
          0% {
            transform: rotateX(0deg) rotateY(-15deg);
          }
          50% {
            transform: rotateX(-5deg) rotateY(0deg);
          }
          100% {
            transform: rotateX(0deg) rotateY(15deg);
          }
        }
        
        .card-bg-animated {
          animation: moveBack 10s ease-in-out infinite, rotateCard 8s ease-in-out infinite;
          transform-style: preserve-3d;
        }
      `}</style>
      
      <div className="card-bg-animated absolute top-1/3 left-1/2 -translate-x-1/2 w-full max-w-4xl">
        <Image
          src="/images/credit-cards.jpg"
          alt="Futuristic Credit Cards with Circuit Board Design"
          width={1000}
          height={650}
          className="w-full h-auto"
          priority
          unoptimized
        />
      </div>
      
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent pointer-events-none"></div>
    </div>
  )
}

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 relative">
      <AnimatedCardBackground />
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 border-b border-yellow-500/20 bg-gradient-to-r from-slate-950/95 via-slate-900/95 to-slate-950/95 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Image
              src="/images/team-classic-logo.png"
              alt="Team Classic"
              width={64}
              height={64}
              className="w-16 h-16"
              priority
            />
            <h1 className="text-3xl font-light tracking-wide text-yellow-300" style={{ fontFamily: 'Georgia, serif', letterSpacing: '0.08em' }}>
              TEAM CLASSIC
            </h1>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <Link href="/dashboard" className="text-sm text-gray-300 hover:text-yellow-400 transition">
              Dashboard
            </Link>
            <Link href="/batch" className="text-sm text-gray-300 hover:text-yellow-400 transition">
              Batch Upload
            </Link>
            <Link href="/chat" className="text-sm text-gray-300 hover:text-yellow-400 transition">
              AI Assistant
            </Link>
            <Link href="/reports" className="text-sm text-gray-300 hover:text-yellow-400 transition">
              Reports
            </Link>
          </div>
        </div>
      </nav>

      <main className="pt-20 relative z-10">
        {/* Hero Section */}
        <section className="relative overflow-hidden px-4 py-16 md:py-24">
          <div className="max-w-7xl mx-auto">
            <div className="">
              {/* Left Content */}
              <div className="space-y-6">
                <Badge className="w-fit bg-yellow-500/20 text-yellow-300 border border-yellow-500/40">
                  <Zap className="w-3 h-3 mr-1" />
                  Next-Gen Fraud Protection
                </Badge>

                <h1 className="text-5xl md:text-6xl font-light text-balance leading-tight" style={{ fontFamily: 'Georgia, serif', letterSpacing: '0.02em' }}>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-yellow-200 to-amber-400">
                    Secure Every
                  </span>
                  <br />
                  <span className="text-white">Credit Card Transaction</span>
                </h1>

                <p className="text-lg text-gray-400 leading-relaxed max-w-lg">
                  Enterprise-grade fraud detection with real-time monitoring, explainable AI decisions, and comprehensive audit trails. Protect your customers with advanced machine learning.
                </p>

                <div className="flex flex-col sm:flex-row gap-4 pt-4">
                  <Link href="/dashboard">
                    <Button size="lg" className="bg-gradient-to-r from-yellow-500 to-amber-600 text-slate-900 hover:shadow-2xl hover:shadow-yellow-500/50 transition font-semibold">
                      <AlertCircle className="w-4 h-4 mr-2" />
                      Launch Dashboard
                    </Button>
                  </Link>
                  <Link href="/chat">
                    <Button size="lg" variant="outline" className="border-yellow-500/40 text-yellow-300 hover:bg-yellow-500/10 bg-transparent">
                      <MessageCircle className="w-4 h-4 mr-2" />
                      Chat with AI
                    </Button>
                  </Link>
                </div>
              </div>


            </div>
          </div>
        </section>

        {/* Key Metrics */}
        <section className="px-4 py-16 border-y border-yellow-500/20">
          <div className="max-w-7xl mx-auto">
            <div className="grid md:grid-cols-4 gap-6">
              <div className="bg-slate-800/40 backdrop-blur-md border border-yellow-500/30 rounded-xl p-6 text-center hover:border-yellow-400/60 transition hover:shadow-lg hover:shadow-yellow-500/20">
                <div className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-yellow-400 mb-2">
                  99.8%
                </div>
                <p className="text-sm text-gray-400">Detection Accuracy</p>
              </div>

              <div className="bg-slate-800/40 backdrop-blur-md border border-amber-500/30 rounded-xl p-6 text-center hover:border-amber-400/60 transition hover:shadow-lg hover:shadow-amber-500/20">
                <div className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-300 to-amber-400 mb-2">
                  {'<50ms'}
                </div>
                <p className="text-sm text-gray-400">Response Time</p>
              </div>

              <div className="bg-slate-800/40 backdrop-blur-md border border-yellow-500/30 rounded-xl p-6 text-center hover:border-amber-400/60 transition hover:shadow-lg hover:shadow-yellow-500/20">
                <div className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-amber-400 mb-2">
                  100%
                </div>
                <p className="text-sm text-gray-400">Audit Trail</p>
              </div>

              <div className="bg-slate-800/40 backdrop-blur-md border border-yellow-500/30 rounded-xl p-6 text-center hover:border-yellow-400/60 transition hover:shadow-lg hover:shadow-yellow-500/20">
                <div className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-amber-400 mb-2">
                  24/7
                </div>
                <p className="text-sm text-gray-400">Monitoring</p>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="px-4 py-16">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-4xl font-light text-center mb-12" style={{ fontFamily: 'Georgia, serif', letterSpacing: '0.03em' }}>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-amber-400">
                Powerful Features
              </span>
            </h2>

            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-slate-800/40 backdrop-blur-md border border-yellow-500/20 rounded-xl p-8 hover:border-yellow-500/60 transition">
                <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-amber-600 rounded-lg flex items-center justify-center mb-4">
                  <AlertCircle className="text-slate-900 w-6 h-6" />
                </div>
                <h3 className="text-xl font-light text-white mb-2" style={{ fontFamily: 'Georgia, serif', letterSpacing: '0.02em' }}>Real-Time Monitoring</h3>
                <p className="text-gray-400">Detect fraudulent transactions instantly with sub-second latency and immediate alerts for suspicious activity.</p>
              </div>

              <div className="bg-slate-800/40 backdrop-blur-md border border-yellow-500/20 rounded-xl p-8 hover:border-yellow-500/60 transition">
                <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-amber-600 rounded-lg flex items-center justify-center mb-4">
                  <BarChart3 className="text-slate-900 w-6 h-6" />
                </div>
                <h3 className="text-xl font-light text-white mb-2" style={{ fontFamily: 'Georgia, serif', letterSpacing: '0.02em' }}>Explainable AI</h3>
                <p className="text-gray-400">Understand every fraud decision with feature importance analysis, risk scoring, and clear reasoning.</p>
              </div>

              <div className="bg-slate-800/40 backdrop-blur-md border border-yellow-500/20 rounded-xl p-8 hover:border-yellow-500/60 transition">
                <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-amber-600 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="text-slate-900 w-6 h-6" />
                </div>
                <h3 className="text-xl font-light text-white mb-2" style={{ fontFamily: 'Georgia, serif', letterSpacing: '0.02em' }}>Secure & Compliant</h3>
                <p className="text-gray-400">Complete audit trails for regulatory compliance with industry-standard security and data protection.</p>
              </div>

              <div className="bg-slate-800/40 backdrop-blur-md border border-yellow-500/20 rounded-xl p-8 hover:border-yellow-500/60 transition">
                <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-amber-600 rounded-lg flex items-center justify-center mb-4">
                  <FileUp className="text-slate-900 w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Batch Processing</h3>
                <p className="text-gray-400">Process large datasets efficiently with CSV upload for historical analysis and comprehensive reporting.</p>
              </div>

              <div className="bg-slate-800/40 backdrop-blur-md border border-yellow-500/20 rounded-xl p-8 hover:border-yellow-500/60 transition">
                <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-amber-600 rounded-lg flex items-center justify-center mb-4">
                  <MessageCircle className="text-slate-900 w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">AI Assistant</h3>
                <p className="text-gray-400">Expert and support modes to answer questions about fraud patterns, detection methods, and system insights.</p>
              </div>

              <div className="bg-slate-800/40 backdrop-blur-md border border-yellow-500/20 rounded-xl p-8 hover:border-yellow-500/60 transition">
                <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-amber-600 rounded-lg flex items-center justify-center mb-4">
                  <Zap className="text-slate-900 w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Performance Reports</h3>
                <p className="text-gray-400">Detailed analytics, confusion matrices, and performance metrics across all risk categories.</p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="px-4 py-16 border-t border-yellow-500/20">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-amber-400">
                Ready to Protect Your Customers?
              </span>
            </h2>
            <p className="text-lg text-gray-400 mb-8 max-w-2xl mx-auto">
              Start using Classic fraud detection today. Real-time monitoring, explainable AI, and enterprise-grade security for your payment systems.
            </p>
            <Link href="/dashboard">
              <Button size="lg" className="bg-gradient-to-r from-yellow-500 to-amber-600 text-slate-900 hover:shadow-2xl hover:shadow-yellow-500/50 transition font-semibold px-8">
                Get Started Now
              </Button>
            </Link>
          </div>
        </section>

        {/* Footer */}
        <footer className="border-t border-yellow-500/20 px-4 py-8">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <p className="text-gray-500 text-sm">
              Classic Fraud Detection - Enterprise Security for Payment Systems
            </p>
            <div className="flex gap-6">
              <Link href="/dashboard" className="text-gray-400 hover:text-yellow-400 text-sm transition">
                Dashboard
              </Link>
              <Link href="/reports" className="text-gray-400 hover:text-yellow-400 text-sm transition">
                Reports
              </Link>
              <Link href="/chat" className="text-gray-400 hover:text-yellow-400 text-sm transition">
                Support
              </Link>
            </div>
          </div>
        </footer>
      </main>
    </div>
  )
}
