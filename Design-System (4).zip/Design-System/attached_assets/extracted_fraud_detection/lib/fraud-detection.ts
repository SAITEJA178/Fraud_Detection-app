// Fraud Detection Engine with Explainability

export interface Transaction {
  id: string
  amount: number
  merchantCategory: string
  timestamp: Date
  location: string
  userHistory: {
    avgAmount: number
    daysSinceLastTransaction: number
    numberOfTransactionsToday: number
    commonMerchantCategories: string[]
  }
  deviceInfo?: {
    isNewDevice: boolean
    previousLocations: string[]
  }
}

export interface FraudScore {
  isFraud: boolean
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'
  score: number
  confidence: number
  featureImportance: {
    feature: string
    importance: number
    value: string | number
    impact: 'increases_risk' | 'decreases_risk'
  }[]
  explanation: string
  auditLog: {
    timestamp: Date
    decision: string
    reasoning: string
  }
}

export class FraudDetectionEngine {
  private thresholds = {
    low: 0.3,
    medium: 0.6,
    high: 0.8,
    critical: 0.9,
  }

  /**
   * Detect fraud in a transaction using multiple signals
   */
  detectFraud(transaction: Transaction): FraudScore {
    const signals: {
      feature: string
      score: number
      importance: number
      impact: 'increases_risk' | 'decreases_risk'
      explanation: string
    }[] = []

    // Signal 1: Amount Anomaly
    const amountZ = (transaction.amount - transaction.userHistory.avgAmount) / Math.max(transaction.userHistory.avgAmount * 0.5, 1)
    const amountScore = Math.min(Math.max(Math.abs(amountZ) / 4, 0), 1) // Normalize to 0-1
    const amountImportance = 0.25

    if (amountScore > 0.3) {
      signals.push({
        feature: 'Amount Anomaly',
        score: amountScore,
        importance: amountImportance,
        impact: amountScore > 0.5 ? 'increases_risk' : 'decreases_risk',
        explanation:
          amountScore > 0.5
            ? `Transaction amount ${transaction.amount} is ${Math.round((amountZ * 100) / 4)}% above user average`
            : `Transaction amount is within normal range for this user`,
      })
    }

    // Signal 2: High Transaction Frequency
    const frequencyScore = Math.min(transaction.userHistory.numberOfTransactionsToday / 10, 1)
    const frequencyImportance = 0.15

    if (frequencyScore > 0.2) {
      signals.push({
        feature: 'High Transaction Frequency',
        score: frequencyScore,
        importance: frequencyImportance,
        impact: frequencyScore > 0.5 ? 'increases_risk' : 'decreases_risk',
        explanation: `${transaction.userHistory.numberOfTransactionsToday} transactions today (typical: 1-3 per day)`,
      })
    }

    // Signal 3: Merchant Category Anomaly
    const isUnusualCategory = !transaction.userHistory.commonMerchantCategories.includes(transaction.merchantCategory)
    const categoryScore = isUnusualCategory ? 0.6 : 0.1
    const categoryImportance = 0.2

    signals.push({
      feature: 'Merchant Category Anomaly',
      score: categoryScore,
      importance: categoryImportance,
      impact: isUnusualCategory ? 'increases_risk' : 'decreases_risk',
      explanation: isUnusualCategory
        ? `${transaction.merchantCategory} is unusual for this user`
        : `Transaction category matches user history`,
    })

    // Signal 4: Device/Location Risk
    const isNewDevice = transaction.deviceInfo?.isNewDevice ?? false
    const isNewLocation =
      transaction.deviceInfo?.previousLocations && !transaction.deviceInfo.previousLocations.includes(transaction.location)

    let deviceLocationScore = 0
    let deviceLocationExplanation = ''

    if (isNewDevice && isNewLocation) {
      deviceLocationScore = 0.8
      deviceLocationExplanation = 'New device + new location combination'
    } else if (isNewDevice || isNewLocation) {
      deviceLocationScore = 0.4
      deviceLocationExplanation = `${isNewDevice ? 'New device' : ''} ${isNewDevice && isNewLocation ? '+' : ''} ${isNewLocation ? 'new location' : ''}`.trim()
    } else {
      deviceLocationScore = 0.05
      deviceLocationExplanation = 'Device and location are known'
    }

    const deviceLocationImportance = 0.25

    signals.push({
      feature: 'Device & Location Risk',
      score: deviceLocationScore,
      importance: deviceLocationImportance,
      impact: deviceLocationScore > 0.3 ? 'increases_risk' : 'decreases_risk',
      explanation: deviceLocationExplanation,
    })

    // Signal 5: Time-based risk
    const hour = new Date(transaction.timestamp).getHours()
    const isOddHour = hour < 6 || hour > 22
    const timeScore = isOddHour ? 0.3 : 0.1
    const timeImportance = 0.1

    signals.push({
      feature: 'Time-based Risk',
      score: timeScore,
      importance: timeImportance,
      impact: isOddHour ? 'increases_risk' : 'decreases_risk',
      explanation: isOddHour ? `Transaction at unusual hour (${hour}:00)` : `Transaction at normal business hours`,
    })

    // Calculate final score using weighted average
    let totalImportance = 0
    let weightedScore = 0

    signals.forEach((signal) => {
      weightedScore += signal.score * signal.importance
      totalImportance += signal.importance
    })

    // Normalize
    const finalScore = totalImportance > 0 ? weightedScore / totalImportance : 0

    // Determine risk level and fraud status
    let riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'
    let isFraud: boolean

    if (finalScore >= this.thresholds.critical) {
      riskLevel = 'CRITICAL'
      isFraud = Math.random() < 0.95 // 95% fraud rate at critical
    } else if (finalScore >= this.thresholds.high) {
      riskLevel = 'HIGH'
      isFraud = Math.random() < 0.75 // 75% fraud rate at high
    } else if (finalScore >= this.thresholds.medium) {
      riskLevel = 'MEDIUM'
      isFraud = Math.random() < 0.4 // 40% fraud rate at medium
    } else {
      riskLevel = 'LOW'
      isFraud = Math.random() < 0.05 // 5% fraud rate at low
    }

    // Calculate confidence
    const confidence = Math.min(finalScore * 1.2, 1)

    // Sort signals by importance
    const sortedSignals = signals.sort((a, b) => b.importance - a.importance)

    // Generate explanation
    const topRisks = sortedSignals.filter((s) => s.impact === 'increases_risk').slice(0, 2)
    const explanation =
      isFraud && topRisks.length > 0
        ? `Flagged as ${riskLevel} risk: ${topRisks.map((s) => s.explanation).join('; ')}`
        : `Flagged as ${riskLevel} risk: Transaction appears legitimate based on user history`

    return {
      isFraud,
      riskLevel,
      score: Math.round(finalScore * 100) / 100,
      confidence: Math.round(confidence * 100) / 100,
      featureImportance: sortedSignals.map((s) => ({
        feature: s.feature,
        importance: Math.round(s.importance * 100),
        value: s.explanation,
        impact: s.impact,
      })),
      explanation,
      auditLog: {
        timestamp: new Date(),
        decision: isFraud ? 'BLOCKED' : 'APPROVED',
        reasoning: explanation,
      },
    }
  }

  /**
   * Generate simulated transactions for demonstration
   */
  generateSampleTransaction(index: number): Transaction {
    const amounts = [15.99, 45.5, 125.0, 250.0, 1200.0, 3500.0]
    const categories = ['Groceries', 'Gas', 'Restaurants', 'Travel', 'Online Shopping', 'Electronics', 'Gaming', 'Subscription']
    const locations = ['New York, NY', 'Los Angeles, CA', 'Chicago, IL', 'Houston, TX', 'Phoenix, AZ']

    const isSuspicious = Math.random() < 0.15 // 15% chance of suspicious transaction

    return {
      id: `TXN-${Date.now()}-${index}`,
      amount: isSuspicious ? amounts[Math.floor(Math.random() * amounts.length)] * 2 : amounts[Math.floor(Math.random() * amounts.length)],
      merchantCategory: categories[Math.floor(Math.random() * categories.length)],
      timestamp: new Date(Date.now() - Math.random() * 3600000),
      location: locations[Math.floor(Math.random() * locations.length)],
      userHistory: {
        avgAmount: 85.5,
        daysSinceLastTransaction: Math.floor(Math.random() * 5),
        numberOfTransactionsToday: Math.floor(Math.random() * 6) + 1,
        commonMerchantCategories: ['Groceries', 'Gas', 'Restaurants', 'Subscription'],
      },
      deviceInfo: {
        isNewDevice: isSuspicious && Math.random() < 0.4,
        previousLocations: ['New York, NY', 'Los Angeles, CA', 'Chicago, IL'],
      },
    }
  }
}

// Singleton instance
export const fraudDetectionEngine = new FraudDetectionEngine()
