'use client'

import React, { useRef, useState } from 'react'
import { useFrame } from '@react-three/fiber'
import { Html } from '@react-three/drei'
import * as THREE from 'three'

interface Card3DProps {
  position: [number, number, number]
  children: React.ReactNode
  scale?: number
  rotationY?: number
}

export function Card3D({ position, children, scale = 1, rotationY = 0 }: Card3DProps) {
  const groupRef = useRef<THREE.Group>(null)
  const [hovered, setHovered] = useState(false)
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 })

  const targetRotation = useRef({ x: 0, y: 0 })

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect()
    const x = (e.clientX - rect.left) / rect.width - 0.5
    const y = (e.clientY - rect.top) / rect.height - 0.5

    setMousePos({ x, y })
    targetRotation.current = {
      x: y * 0.3,
      y: x * 0.3,
    }
  }

  useFrame(() => {
    if (!groupRef.current) return

    // Smooth rotation animation
    groupRef.current.rotation.x += (targetRotation.current.x - groupRef.current.rotation.x) * 0.1
    groupRef.current.rotation.y += (targetRotation.current.y - groupRef.current.rotation.y) * 0.1

    // Floating animation
    groupRef.current.position.z = position[2] + Math.sin(Date.now() * 0.001) * 0.3

    // Scale on hover
    if (hovered) {
      groupRef.current.scale.x = Math.min(groupRef.current.scale.x + 0.01, scale * 1.1)
      groupRef.current.scale.y = Math.min(groupRef.current.scale.y + 0.01, scale * 1.1)
      groupRef.current.scale.z = Math.min(groupRef.current.scale.z + 0.01, scale * 1.1)
    } else {
      groupRef.current.scale.x = Math.max(groupRef.current.scale.x - 0.01, scale)
      groupRef.current.scale.y = Math.max(groupRef.current.scale.y - 0.01, scale)
      groupRef.current.scale.z = Math.max(groupRef.current.scale.z - 0.01, scale)
    }
  })

  return (
    <group ref={groupRef} position={position} rotation={[0, rotationY, 0]}>
      <mesh
        onPointerEnter={() => setHovered(true)}
        onPointerLeave={() => setHovered(false)}
        onPointerMove={handleMouseMove}
      >
        <boxGeometry args={[3, 2, 0.2]} />
        <meshStandardMaterial
          color={hovered ? '#0099ff' : '#0066cc'}
          metalness={0.8}
          roughness={0.2}
          emissive={hovered ? '#00ccff' : '#0033ff'}
          emissiveIntensity={hovered ? 0.5 : 0.2}
        />
      </mesh>

      {/* Border glow */}
      <mesh position={[0, 0, 0.11]}>
        <boxGeometry args={[3.05, 2.05, 0.01]} />
        <meshStandardMaterial
          color={hovered ? '#00ff88' : '#00cc66'}
          emissive={hovered ? '#00ff88' : '#00cc66'}
          emissiveIntensity={hovered ? 0.8 : 0.4}
          transparent
          opacity={hovered ? 0.8 : 0.4}
        />
      </mesh>

      {/* HTML content */}
      <Html scale={1 / scale} position={[0, 0, 0.15]} distanceFactor={1.2}>
        <div
          className="w-96 pointer-events-none select-none"
          style={{
            transform: `perspective(1000px) rotateX(${-mousePos.y * 5}deg) rotateY(${mousePos.x * 5}deg)`,
          }}
        >
          {children}
        </div>
      </Html>
    </group>
  )
}
