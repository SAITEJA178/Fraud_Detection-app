'use client'

import React, { useRef, useEffect, useState } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { Environment, PerspectiveCamera } from '@react-three/drei'
import { CreditCard3D } from './CreditCard3D'
import * as THREE from 'three'

// Circuit Board geometry component
function CircuitBoard() {
  const meshRef = useRef<THREE.Group>(null)
  const linesRef = useRef<THREE.LineSegments>(null)

  useEffect(() => {
    if (!linesRef.current) return

    const geometry = new THREE.BufferGeometry()
    const positions: number[] = []

    // Create circuit traces
    const traceCount = 150
    for (let i = 0; i < traceCount; i++) {
      const x1 = (Math.random() - 0.5) * 20
      const y1 = (Math.random() - 0.5) * 20
      const z1 = (Math.random() - 0.5) * 2

      const x2 = x1 + (Math.random() - 0.5) * 4
      const y2 = y1 + (Math.random() - 0.5) * 4
      const z2 = z1 + (Math.random() - 0.5) * 1

      positions.push(x1, y1, z1, x2, y2, z2)
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(positions), 3))

    const material = new THREE.LineBasicMaterial({
      color: 0x0066ff,
      linewidth: 2,
      transparent: true,
      opacity: 0.6,
    })

    linesRef.current.geometry = geometry
    linesRef.current.material = material
  }, [])

  return (
    <group ref={meshRef}>
      <lineSegments ref={linesRef} />
    </group>
  )
}

// Floating detection particles
function DetectionParticles() {
  const pointsRef = useRef<THREE.Points>(null)
  const particleCount = 200

  useEffect(() => {
    if (!pointsRef.current) return

    const geometry = new THREE.BufferGeometry()
    const positions = new Float32Array(particleCount * 3)
    const velocities = new Float32Array(particleCount * 3)
    const colors = new Float32Array(particleCount * 3)

    for (let i = 0; i < particleCount; i++) {
      const i3 = i * 3

      // Position
      positions[i3] = (Math.random() - 0.5) * 20
      positions[i3 + 1] = (Math.random() - 0.5) * 20
      positions[i3 + 2] = (Math.random() - 0.5) * 2

      // Velocity
      velocities[i3] = (Math.random() - 0.5) * 0.05
      velocities[i3 + 1] = (Math.random() - 0.5) * 0.05
      velocities[i3 + 2] = (Math.random() - 0.5) * 0.02

      // Color - mix of blue and yellow-green (detection colors)
      const isGreen = Math.random() > 0.5
      if (isGreen) {
        colors[i3] = 0.4 // R
        colors[i3 + 1] = 1.0 // G
        colors[i3 + 2] = 0.2 // B
      } else {
        colors[i3] = 0.0 // R
        colors[i3 + 1] = 0.4 // G
        colors[i3 + 2] = 1.0 // B
      }
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3))
    ;(geometry as any).velocities = velocities

    const material = new THREE.PointsMaterial({
      size: 0.3,
      vertexColors: true,
      sizeAttenuation: true,
      transparent: true,
      opacity: 0.8,
    })

    pointsRef.current.geometry = geometry
    pointsRef.current.material = material
  }, [])

  useFrame(() => {
    if (!pointsRef.current?.geometry) return

    const positions = pointsRef.current.geometry.attributes.position.array as Float32Array
    const velocities = (pointsRef.current.geometry as any).velocities as Float32Array

    for (let i = 0; i < particleCount; i++) {
      const i3 = i * 3

      positions[i3] += velocities[i3]
      positions[i3 + 1] += velocities[i3 + 1]
      positions[i3 + 2] += velocities[i3 + 2]

      // Bounce off boundaries
      if (positions[i3] > 10) {
        positions[i3] = -10
      } else if (positions[i3] < -10) {
        positions[i3] = 10
      }

      if (positions[i3 + 1] > 10) {
        positions[i3 + 1] = -10
      } else if (positions[i3 + 1] < -10) {
        positions[i3 + 1] = 10
      }
    }

    pointsRef.current.geometry.attributes.position.needsUpdate = true
  })

  return <points ref={pointsRef} />
}

// Camera controller with mouse reactivity
function CameraController() {
  const { camera } = useThree()
  const mouseX = useRef(0)
  const mouseY = useRef(0)

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouseX.current = (e.clientX / window.innerWidth) * 2 - 1
      mouseY.current = -(e.clientY / window.innerHeight) * 2 + 1
    }

    window.addEventListener('mousemove', handleMouseMove)
    return () => window.removeEventListener('mousemove', handleMouseMove)
  }, [])

  useFrame(() => {
    // Smooth camera rotation following mouse
    camera.position.x = mouseX.current * 3
    camera.position.y = mouseY.current * 2
    camera.lookAt(0, 0, 0)
  })

  return null
}

export function CircuitBoardScene({ children }: { children?: React.ReactNode }) {
  return (
    <div className="relative w-full h-screen bg-slate-900">
      <Canvas className="absolute inset-0">
        <PerspectiveCamera makeDefault position={[0, 0, 8]} fov={75} />
        <color attach="background" args={['#0f172a']} />

        {/* Lighting */}
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} intensity={1} />
        <pointLight position={[-10, -10, 5]} intensity={0.5} color={0x00ff88} />

        {/* 3D Elements */}
        <CircuitBoard />
        <DetectionParticles />
        <CreditCard3D />
        <CameraController />

        {/* Environment for realistic lighting */}
        <Environment preset="night" />
      </Canvas>

      {/* UI Overlay */}
      <div className="absolute inset-0 pointer-events-none">{children}</div>
    </div>
  )
}
