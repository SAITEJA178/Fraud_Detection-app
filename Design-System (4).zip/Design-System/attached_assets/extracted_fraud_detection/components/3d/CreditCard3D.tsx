'use client'

import { useRef, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import { Text, RoundedBox } from '@react-three/drei'
import * as THREE from 'three'

export function CreditCard3D() {
  const groupRef = useRef<THREE.Group>(null)
  const cardRef = useRef<THREE.Mesh>(null)
  const glowRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (!groupRef.current) return

    // Move card toward camera over time (Z axis)
    groupRef.current.position.z = Math.sin(state.clock.elapsedTime * 0.5) * 2 - 1

    // Gentle rotation based on mouse position
    groupRef.current.rotation.x = (state.mouse.y * Math.PI) / 8
    groupRef.current.rotation.y = (state.mouse.x * Math.PI) / 8

    // Hover animation
    groupRef.current.position.y = Math.sin(state.clock.elapsedTime * 0.8) * 0.5

    // Pulse glow effect
    if (glowRef.current) {
      glowRef.current.scale.z = 1 + Math.sin(state.clock.elapsedTime * 2) * 0.3
    }
  })

  // Create glowing material
  const glowMaterial = useMemo(() => {
    return new THREE.MeshBasicMaterial({
      color: new THREE.Color(0x00bfff),
      transparent: true,
      opacity: 0.2,
    })
  }, [])

  return (
    <group ref={groupRef} position={[0, 0, 0]}>
      {/* Glow effect halo */}
      <mesh ref={glowRef} position={[0, 0, -0.1]}>
        <planeGeometry args={[6, 3.8]} />
        <meshBasicMaterial
          color={0x00bfff}
          transparent
          opacity={0.1}
          side={THREE.DoubleSide}
        />
      </mesh>

      {/* Credit Card */}
      <RoundedBox
        ref={cardRef}
        args={[3.5, 2.2, 0.1]}
        radius={0.2}
        smoothness={4}
        position={[0, 0, 0]}
      >
        <meshStandardMaterial
          color={0x0a1428}
          metalness={0.6}
          roughness={0.2}
          emissive={0x001a4d}
          emissiveIntensity={0.3}
        />
      </RoundedBox>

      {/* Circuit board pattern overlay */}
      <mesh position={[0, 0, 0.06]}>
        <planeGeometry args={[3.4, 2.1]} />
        <meshBasicMaterial
          map={createCircuitPattern()}
          transparent
          opacity={0.4}
          side={THREE.FrontSide}
        />
      </mesh>

      {/* Card brand text */}
      <Text
        position={[0.8, 0.7, 0.07]}
        fontSize={0.25}
        color="#ffffff"
        anchorX="left"
        font="/fonts/GeistMono_Bold.ttf"
      >
        CLASSIC
      </Text>

      {/* Card number with glow */}
      <Text
        position={[-1.5, -0.3, 0.07]}
        fontSize={0.18}
        color="#00ffff"
        anchorX="left"
        font="/fonts/GeistMono_Regular.ttf"
        letterSpacing={0.05}
      >
        4321 9876 2100 3456
      </Text>

      {/* Validity date */}
      <Text
        position={[-1.5, -0.8, 0.07]}
        fontSize={0.12}
        color="#cccccc"
        anchorX="left"
        font="/fonts/GeistMono_Regular.ttf"
      >
        VALID THRU 12/25
      </Text>

      {/* Cardholder name */}
      <Text
        position={[-1.5, -1.0, 0.07]}
        fontSize={0.14}
        color="#ffffff"
        anchorX="left"
        font="/fonts/Geist_Regular.ttf"
      >
        CARDHOLDER NAME
      </Text>

      {/* Chip */}
      <mesh position={[1.3, -0.6, 0.08]}>
        <boxGeometry args={[0.3, 0.3, 0.02]} />
        <meshStandardMaterial
          color={0xd4af37}
          metalness={0.8}
          roughness={0.1}
          emissive={0xffd700}
          emissiveIntensity={0.5}
        />
      </mesh>

      {/* Chip grid pattern */}
      {Array.from({ length: 3 }).map((_, i) =>
        Array.from({ length: 3 }).map((_, j) => (
          <mesh
            key={`chip-${i}-${j}`}
            position={[1.2 + (i - 1) * 0.08, -0.5 + (j - 1) * 0.08, 0.085]}
          >
            <boxGeometry args={[0.02, 0.02, 0.01]} />
            <meshStandardMaterial color={0xffd700} metalness={1} roughness={0} />
          </mesh>
        ))
      )}

      {/* Glowing points (detection particles) */}
      {Array.from({ length: 15 }).map((_, i) => {
        const angle = (i / 15) * Math.PI * 2
        const radius = 1.5
        return (
          <mesh
            key={`glow-${i}`}
            position={[
              Math.cos(angle) * radius,
              Math.sin(angle) * radius * 0.7,
              0.1,
            ]}
          >
            <sphereGeometry args={[0.08, 16, 16]} />
            <meshBasicMaterial
              color={i % 2 === 0 ? 0x00ffff : 0xff4444}
              emissive={i % 2 === 0 ? 0x00ffff : 0xff4444}
              emissiveIntensity={1}
            />
          </mesh>
        )
      })}

      {/* Glow sphere effect */}
      <mesh position={[0, 0, 0.05]}>
        <sphereGeometry args={[2.5, 32, 32]} />
        <meshBasicMaterial
          color={0x00bfff}
          transparent
          opacity={0.05}
          side={THREE.BackSide}
        />
      </mesh>
    </group>
  )
}

// Create a simple circuit pattern texture
function createCircuitPattern() {
  const canvas = document.createElement('canvas')
  canvas.width = 512
  canvas.height = 320

  const ctx = canvas.getContext('2d')
  if (!ctx) return new THREE.Texture()

  ctx.fillStyle = '#0a1428'
  ctx.fillRect(0, 0, 512, 320)

  // Draw circuit traces
  ctx.strokeStyle = '#0066ff'
  ctx.lineWidth = 2

  for (let i = 0; i < 15; i++) {
    const startX = Math.random() * 512
    const startY = Math.random() * 320
    ctx.beginPath()
    ctx.moveTo(startX, startY)
    for (let j = 0; j < 4; j++) {
      ctx.lineTo(
        startX + Math.random() * 100 - 50,
        startY + Math.random() * 100 - 50
      )
    }
    ctx.stroke()
  }

  // Draw nodes
  ctx.fillStyle = '#00ffff'
  for (let i = 0; i < 30; i++) {
    const x = Math.random() * 512
    const y = Math.random() * 320
    ctx.beginPath()
    ctx.arc(x, y, 3, 0, Math.PI * 2)
    ctx.fill()
  }

  const texture = new THREE.CanvasTexture(canvas)
  texture.needsUpdate = true
  return texture
}
